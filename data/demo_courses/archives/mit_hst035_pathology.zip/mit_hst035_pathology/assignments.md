# MIT HST.035 Principle and Practice of Human Pathology (Spring 2003): assignments

> Source: Principle and Practice of Human Pathology (Spring 2003), Kamran Badizadegan, MIT OpenCourseWare. https://ocw.mit.edu/courses/hst-035-principle-and-practice-of-human-pathology-spring-2003/pages/assignments/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| ASSIGNMENTS | SOLUTIONS |

| Homework Assignment 1 (PDF) | (PDF) |

| Homework Assignment 2 (PDF) | (PDF) |

| Homework Assignment 3 Write 4 questions with answers for the midterm exam. | |

| Homework Assignment 4 (PDF) | (PDF) |

| Homework Assignment 5 (PDF) | (PDF) |

| Homework Assignment 6 (PDF) | (PDF) |

| Homework Assignment 7 Write 4 questions with answers for the final exam. | |
