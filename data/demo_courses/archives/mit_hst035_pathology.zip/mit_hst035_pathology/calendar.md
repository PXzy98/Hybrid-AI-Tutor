# MIT HST.035 Principle and Practice of Human Pathology (Spring 2003): calendar

> Source: Principle and Practice of Human Pathology (Spring 2003), Kamran Badizadegan, MIT OpenCourseWare. https://ocw.mit.edu/courses/hst-035-principle-and-practice-of-human-pathology-spring-2003/pages/calendar/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| SES # | TOPICS | KEY DATES |

| 1 | Introduction to Human Pathology and Diagnostic Medicine (1 hr.) - Dr. Badizadegan Lab: Cells and Tissues – Part 1 (2 hrs.) | Homework 1 out |

| 2 | Cytoskeleton and the Extracellular Matrix: “Scaffoldings of Life” (1 hr.) - Dr. Ingber Epithelial Structure and Function (1 hr.) - Dr. Badizadegan The Immune System (1 hr.) - Dr. Badizadegan | |

| 3 | Cell Injury, Adaptation and Death (1 hr.) - Dr. Badizadegan Lab: Cells and Tissues – Part 2 (2 hrs.) | Homework 1 due |

| 4 | Acute and Chronic Inflammation (1 hr.) - Dr. Badizadegan Tissue Repair, Fibrosis and Healing (1 hr.) - Dr. Badizadegan Diseases of Immunity (1 hr.) - Dr. Mitchell | |

| 5 | Infectious Diseases: “The Biological Conflict of Interest” (1 hr.) - Dr. Badizadegan Lab: Infection and Immunity (2 hrs.) | |

| 6 | Transplantation: “Friendly Organs in a Hostile Environment” (1 hr.) - Dr. Colvin Tissue Engineering and Organ Fabrication: “Medical Rationale and Engineering Challenges” (1 hr.) Minicases (1 hr.) - Dr. Badizadegan | Homework 2 out |

| 7 | Host Response to Artificial Materials and Implanted Devices (1 hr.) - Dr. Schoen Lab: Transplantation and Biomaterials (2 hrs.) | |

| 8 | Introduction to Organ Systems Pathology (1 hr.) - Dr. Badizadegan Are We What We Eat? “The Link Between Diet and Disease Development” (1 hr.) - Dr. Hu Environmental Exposure: “Is It Making You Sick?” (1 hr.) - Dr. Dockery | |

| 9 | Cardiomyopathies: “Many Roads to a Broken Heart” (1 hr.) - Dr. Seidman Lab: The Heart (2 hrs.) | Homework 2 due |

| 10 | Vascular Pathobiology: “Endothelium as Nature’s Blood Container” (1.5 hrs.) - Dr. Gimbrone Minicases (0.5 hrs.) - Dr. Badizadegan Ischemia and Infarction (1 hr.) - Dr. Badizadegan | |

| 11 | Patterns and Consequences of Glomerular Damage (1 hr.) - Dr. Rennke Lab: Kidneys and Blood Vessels (2 hrs.) | Homework 3 due Homework 4 out |

| 12 | Genetic Disorders (1 hr.) - Dr. Badizadegan Minicases (0.5 hrs.) - Dr. Badizadegan Diseases of the Lung (1.5 hrs.) | |

| 13 | The Liver (1 hr.) - Dr. Badizadegan Lab: Lungs and Liver (2 hrs.) | |

| 14 | Gastrointestinal Disorders: “Guts with No Glory!” (2 hrs.) - Dr. Badizadegan Genetic Progression in Gastrointestinal Neoplasia (1 hr.) - Dr. Redston | Homework 4 due Homework 5 out |

| 15 | Cervical Neoplasia: “Lessons from Viral Oncogenesis” (1 hr.) - Dr. Crum Lab: The Gastrointestinal Tract (2 hrs.) | Homework 5 due |

| 16 | Mid-Term Exam (1 hr.) Feedback Session and Review of the Mid-Term Exam (1 hr.) Lymphoid Neoplasms (1 hr.) - Dr. Aster | |

| 17 | Sickle Cell Disease: “From Membrane Pathophysiology to Membrane-Targeted Therapy” (1 hr.) - Dr. Brugnara Lab: Red and White Blood Cells (2 hrs.) | Homework 6 out |

| 18 | Introduction to the Nervous System (1 hr.) Toxic Proteins and Neurodegenerative Diseases (1 hr.) - Dr. Feany CNS Neoplasia (1 hr.) - Dr. Louis | |

| 19 | Diseases of Skeletal Muscle (1 hr.) - Dr. Lidov Lab: The Nervous System (2 hrs.) | |

| 20 | Surgical Pathology and Other Gold Standards (1 hr.) - Dr. Badizadegan Molecular and Cytogenetic Analyses in Diagnostic Pathology (1 hr.) - Dr. Fletcher DNA Microarrays in Cancer Diagnosis and Management (1 hr.) - Dr. Golub | Homework 6 due |

| 21 | Bioinformatics in Pathology: “Can any Useful Information be Extracted from all this Data?” (1 hr.) Functional Imaging (1 hr.) - Dr. Rosen Molecular Imaging (1 hr.) | |

| 22 | Lab: The Clinical Laboratories (Medical Area) (3 hrs.) | Homework 7 due |

| 23 | Optical Coherence Tomography: “Shedding Light on Human Disease” (1 hr.) - Dr. Tearney Optical Spectroscopy: “Diagnosis in a Flash!” (1 hr.) - Dr. Feld Transfer of Healthcare Technologies: “How to Make New Diagnostic Technologies a Clinical Reality?” (1 hr.) - Dr. Murray | |

| 24 | Student Presentations (3 hrs.) | |

| 25 | Student Presentations (3 hrs.) | |

| 26 | Autopsy: “The Final Answer?” (Medical Area) (1 hr.) - Dr. Badizadegan Lab: Autopsy Conference (Medical Area) (2 hrs.) | |

| 27 | Pathology and the Law (1 hr.) - Dr. Bieber Minicases (1 hr.) - Dr. Badizadegan Human Pathology: “Past, Present, and the Future” (1 hr.) - Panel Discussion | |

| 28 | Final Exam | |
