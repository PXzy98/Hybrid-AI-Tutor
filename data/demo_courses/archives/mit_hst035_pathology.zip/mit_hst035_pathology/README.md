# MIT HST.035: Principle and Practice of Human Pathology (Spring 2003)

Open course material used as a demo and test course of the Hybrid AI Tutor (course type `medical_science`). See [../README.md](../README.md).

- **Source**: [https://ocw.mit.edu/courses/hst-035-principle-and-practice-of-human-pathology-spring-2003/](https://ocw.mit.edu/courses/hst-035-principle-and-practice-of-human-pathology-spring-2003/)
- **Author**: Kamran Badizadegan, MIT OpenCourseWare
- **License**: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Non-commercial use only; adaptations are shared under the same license.
- **Retrieved**: 2026-11-12
- **Changes**: files renamed and numbered as modules; web pages converted to Markdown with an attribution header. PDFs are unchanged.
- The authors and their institution do not endorse this project.

## Course-level documents

Uploaded to the course (not to a module): the syllabus and, where the course has them, the calendar, assignments and exams (questions only).

- `syllabus.md`
- `calendar.md`
- `assignments.md`
- `assignments/homework1.pdf`
- `assignments/homework2.pdf`
- `assignments/homework4.pdf`
- `assignments/homework5.pdf`
- `assignments/homework6.pdf`

## Instructor only

Solutions and answer keys. **Never upload them as course material**: students would get the answers. They are kept to check generated quizzes.

- `instructor_only/assignments/homework1_answer.pdf`
- `instructor_only/assignments/homework2_answer.pdf`
- `instructor_only/assignments/homework4_answers.pdf`
- `instructor_only/assignments/homework5_answers.pdf`
- `instructor_only/assignments/homework6_answers.pdf`

## Modules

| Module | Title | File |
|---|---|---|
| 1 | Introduction to human pathology and diagnostic medicine | `modules/01_introduction_to_human_pathology_and_diagnostic_m.pdf` |
| 2 | Epithelial structure and function | `modules/02_epithelial_structure_and_function.pdf` |
| 3 | The immune system | `modules/03_the_immune_system.pdf` |
| 4 | Cell injury, adaptation and death | `modules/04_cell_injury_adaptation_and_death.pdf` |
| 5 | Acute and chronic inflammation | `modules/05_acute_and_chronic_inflammation.pdf` |
| 6 | Tissue repair, fibrosis and healing | `modules/06_tissue_repair_fibrosis_and_healing.pdf` |
| 7 | Infectious diseases | `modules/07_infectious_diseases.pdf` |
| 8 | Transplantation | `modules/08_transplantation.pdf` |
| 9 | Diet and disease development | `modules/09_diet_and_disease_development.pdf` |
| 10 | Ischemia and infarction | `modules/10_ischemia_and_infarction.pdf` |
| 11 | Genetic disorders | `modules/11_genetic_disorders.pdf` |
| 12 | The liver | `modules/12_the_liver.pdf` |
