# MIT RES.6-007 Signals and Systems (Spring 2011): assignments

> Source: Signals and Systems (Spring 2011), Alan V. Oppenheim, MIT OpenCourseWare. https://ocw.mit.edu/courses/res-6-007-signals-and-systems-spring-2011/pages/assignments/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| LEC # | TOPICS | PROBLEM SETS | SOLUTIONS |

| 1 | Introduction | (PDF) | (PDF) |

| 2 | Signals and systems: Part I | (PDF) | (PDF) |

| 3 | Signals and systems: Part II | (PDF) | (PDF) |

| 4 | Convolution | (PDF) | (PDF) |

| 5 | Properties of linear, time-invariant systems | (PDF) | (PDF) |

| 6 | Systems represented by differential and difference equations | (PDF) | (PDF) |

| 7 | Continuous-time Fourier series | (PDF) | (PDF) |

| 8 | Continuous-time Fourier transform | (PDF) | (PDF) |

| 9 | Fourier transform properties | (PDF) | (PDF) |

| 10 | Discrete-time Fourier series | (PDF) | (PDF) |

| 11 | Discrete-time Fourier transform | (PDF) | (PDF) |

| 12 | Filtering | (PDF) | (PDF) |

| 13 | Continuous-time modulation | (PDF) | (PDF) |

| 14 | Demonstration of amplitude modulation | (PDF) | (PDF) |

| 15 | Discrete-time modulation | (PDF) | (PDF) |

| 16 | Sampling | (PDF) | (PDF) |

| 17 | Interpolation | (PDF) | (PDF) |

| 18 | Discrete-time processing of continuous-time signals | (PDF) | (PDF) |

| 19 | Discrete-time sampling | (PDF) | (PDF) |

| 20 | The Laplace transform | (PDF) | (PDF) |

| 21 | Continuous-time second-order systems | (PDF) | (PDF) |

| 22 | The z-transform | (PDF) | (PDF) |

| 23 | Mapping continuous-time filters to discrete-time filters | (PDF) | (PDF) |

| 24 | Butterworth filters | (PDF) | (PDF) |

| 25 | Feedback | (PDF) | (PDF) |

| 26 | Feedback example: The inverted pendulum | (PDF) | (PDF) |
