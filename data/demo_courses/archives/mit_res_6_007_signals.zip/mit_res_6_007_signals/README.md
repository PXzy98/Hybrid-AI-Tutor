# MIT RES.6-007: Signals and Systems (Spring 2011)

Open course material used as a demo and test course of the Hybrid AI Tutor (course type `ece`). See [../README.md](../README.md).

- **Source**: [https://ocw.mit.edu/courses/res-6-007-signals-and-systems-spring-2011/](https://ocw.mit.edu/courses/res-6-007-signals-and-systems-spring-2011/)
- **Author**: Alan V. Oppenheim, MIT OpenCourseWare
- **License**: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Non-commercial use only; adaptations are shared under the same license.
- **Retrieved**: 2026-11-12
- **Changes**: files renamed and numbered as modules; web pages converted to Markdown with an attribution header. PDFs are unchanged.
- The authors and their institution do not endorse this project.

## Course-level documents

Uploaded to the course (not to a module): the syllabus and, where the course has them, the calendar, assignments and exams (questions only).

- `syllabus.md`
- `assignments.md`
- `assignments/problem_set_1.pdf`
- `assignments/problem_set_2.pdf`
- `assignments/problem_set_3.pdf`
- `assignments/problem_set_4.pdf`
- `assignments/problem_set_5.pdf`
- `assignments/problem_set_6.pdf`
- `assignments/problem_set_7.pdf`
- `assignments/problem_set_8.pdf`
- `assignments/problem_set_9.pdf`
- `assignments/problem_set_10.pdf`
- `assignments/problem_set_11.pdf`
- `assignments/problem_set_12.pdf`
- `assignments/problem_set_13.pdf`
- `assignments/problem_set_14.pdf`
- `assignments/problem_set_15.pdf`
- `assignments/problem_set_16.pdf`
- `assignments/problem_set_17.pdf`
- `assignments/problem_set_18.pdf`
- `assignments/problem_set_19.pdf`
- `assignments/problem_set_20.pdf`
- `assignments/problem_set_21.pdf`
- `assignments/problem_set_22.pdf`
- `assignments/problem_set_23.pdf`
- `assignments/problem_set_24.pdf`
- `assignments/problem_set_25.pdf`
- `assignments/problem_set_26.pdf`

## Instructor only

Solutions and answer keys. **Never upload them as course material**: students would get the answers. They are kept to check generated quizzes.

- `instructor_only/assignments/problem_set_1_solutions.pdf`
- `instructor_only/assignments/problem_set_2_solutions.pdf`
- `instructor_only/assignments/problem_set_3_solutions.pdf`
- `instructor_only/assignments/problem_set_4_solutions.pdf`
- `instructor_only/assignments/problem_set_5_solutions.pdf`
- `instructor_only/assignments/problem_set_6_solutions.pdf`
- `instructor_only/assignments/problem_set_7_solutions.pdf`
- `instructor_only/assignments/problem_set_8_solutions.pdf`
- `instructor_only/assignments/problem_set_9_solutions.pdf`
- `instructor_only/assignments/problem_set_10_solutions.pdf`
- `instructor_only/assignments/problem_set_11_solutions.pdf`
- `instructor_only/assignments/problem_set_12_solutions.pdf`
- `instructor_only/assignments/problem_set_13_solutions.pdf`
- `instructor_only/assignments/problem_set_14_solutions.pdf`
- `instructor_only/assignments/problem_set_15_solutions.pdf`
- `instructor_only/assignments/problem_set_16_solutions.pdf`
- `instructor_only/assignments/problem_set_17_solutions.pdf`
- `instructor_only/assignments/problem_set_18_solutions.pdf`
- `instructor_only/assignments/problem_set_19_solutions.pdf`
- `instructor_only/assignments/problem_set_20_solutions.pdf`
- `instructor_only/assignments/problem_set_21_solutions.pdf`
- `instructor_only/assignments/problem_set_22_solutions.pdf`
- `instructor_only/assignments/problem_set_23_solutions.pdf`
- `instructor_only/assignments/problem_set_24_solutions.pdf`
- `instructor_only/assignments/problem_set_25_solutions.pdf`
- `instructor_only/assignments/problem_set_26_solutions.pdf`

## Modules

| Module | Title | File |
|---|---|---|
| 1 | Lecture 1: Introduction | `modules/01_lecture_1_introduction.pdf` |
| 2 | Lecture 2: Signals and Systems: Part I | `modules/02_lecture_2_signals_and_systems_part_i.pdf` |
| 3 | Lecture 3: Signals and Systems: Part II | `modules/03_lecture_3_signals_and_systems_part_ii.pdf` |
| 4 | Lecture 4: Convolution | `modules/04_lecture_4_convolution.pdf` |
| 5 | Lecture 5: Properties of Linear, Time-Invariant Systems | `modules/05_lecture_5_properties_of_linear_time_invariant_sy.pdf` |
| 6 | Lecture 6: Systems Represented by Differential and Difference Equations | `modules/06_lecture_6_systems_represented_by_differential_an.pdf` |
| 7 | Lecture 7: Continuous-Time Fourier Series | `modules/07_lecture_7_continuous_time_fourier_series.pdf` |
| 8 | Lecture 8: Continuous-Time Fourier Transform | `modules/08_lecture_8_continuous_time_fourier_transform.pdf` |
| 9 | Lecture 9: Fourier Transform Properties | `modules/09_lecture_9_fourier_transform_properties.pdf` |
| 10 | Lecture 10: Discrete-Time Fourier Series | `modules/10_lecture_10_discrete_time_fourier_series.pdf` |
| 11 | Lecture 11: Discrete-Time Fourier Transform | `modules/11_lecture_11_discrete_time_fourier_transform.pdf` |
| 12 | Lecture 12: Filtering | `modules/12_lecture_12_filtering.pdf` |
| 13 | Lecture 13: Continuous-Time Modulation | `modules/13_lecture_13_continuous_time_modulation.pdf` |
| 14 | Lecture 14: Demonstration of Amplitude Modulation | `modules/14_lecture_14_demonstration_of_amplitude_modulation.pdf` |
| 15 | Lecture 15: Discrete-Time Modulation | `modules/15_lecture_15_discrete_time_modulation.pdf` |
| 16 | Lecture 16: Sampling | `modules/16_lecture_16_sampling.pdf` |
| 17 | Lecture 17: Interpolation | `modules/17_lecture_17_interpolation.pdf` |
| 18 | Lecture 18: Mapping Continuous-time Filters to Discrete-time Filters | `modules/18_lecture_18_mapping_continuous_time_filters_to_di.pdf` |
| 19 | Lecture 19: Continuous-Time Second-Order Systems | `modules/19_lecture_19_continuous_time_second_order_systems.pdf` |
| 20 | Lecture 20: The Laplace Transform | `modules/20_lecture_20_the_laplace_transform.pdf` |
| 21 | Lecture 21: Continuous-Time Second-Order Systems | `modules/21_lecture_21_continuous_time_second_order_systems.pdf` |
| 22 | Lecture 22: The z-Transform | `modules/22_lecture_22_the_z_transform.pdf` |
| 23 | Lecture 23: Mapping Continuous Time Filters to Discrete-Time Filters | `modules/23_lecture_23_mapping_continuous_time_filters_to_di.pdf` |
| 24 | Lecture 24: Butterworth Filters | `modules/24_lecture_24_butterworth_filters.pdf` |
| 25 | Lecture 25: Feedback | `modules/25_lecture_25_feedback.pdf` |
| 26 | Lecture 26: Feedback Example: The Inverted Pendulum | `modules/26_lecture_26_feedback_example_the_inverted_pendulu.pdf` |
