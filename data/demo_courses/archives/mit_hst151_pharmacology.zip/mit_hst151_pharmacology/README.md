# MIT HST.151: Principles of Pharmacology (Spring 2005)

Open course material used as a demo and test course of the Hybrid AI Tutor (course type `medical_science`). See [../README.md](../README.md).

- **Source**: [https://ocw.mit.edu/courses/hst-151-principles-of-pharmacology-spring-2005/](https://ocw.mit.edu/courses/hst-151-principles-of-pharmacology-spring-2005/)
- **Author**: Carl Rosow, Gary Strichartz, and Carol Walsh, MIT OpenCourseWare
- **License**: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Non-commercial use only; adaptations are shared under the same license.
- **Retrieved**: 2026-11-12
- **Changes**: files renamed and numbered as modules; web pages converted to Markdown with an attribution header. PDFs are unchanged.
- The authors and their institution do not endorse this project.

## Course-level documents

Uploaded to the course (not to a module): the syllabus and, where the course has them, the calendar, assignments and exams (questions only).

- `syllabus.md`
- `calendar.md`
- `assignments.md`
- `assignments/0208_sulfa_notes.pdf`
- `assignments/0208_sulfa_slide.pdf`
- `assignments/0310_oral_notes.pdf`
- `assignments/0310_oral_slides.pdf`
- `assignments/case_topic_desc.pdf`
- `assignments/ps2005.pdf`
- `exams.md`
- `exams/2005_final.pdf`
- `exams/2005_midterm.pdf`

## Instructor only

Solutions and answer keys. **Never upload them as course material**: students would get the answers. They are kept to check generated quizzes.

- `instructor_only/assignments/ps2005_soln.pdf`

## Modules

| Module | Title | File |
|---|---|---|
| 1 | Introduction: receptors and dose-response | `modules/01_introduction_receptors_and_dose_response.pdf` |
| 2 | Pharmacokinetics I and II | `modules/02_pharmacokinetics_i_and_ii.pdf` |
| 3 | Case: anticholinesterase | `modules/03_case_anticholinesterase.pdf` |
| 4 | Autonomic pharmacology; antidysrhythmics | `modules/04_autonomic_pharmacology_antidysrhythmics.pdf` |
| 5 | Antiinflammatory drugs | `modules/05_antiinflammatory_drugs.pdf` |
| 6 | Vasoactive drugs I | `modules/06_vasoactive_drugs_i.pdf` |
| 7 | Vasoactive drugs II: heart failure | `modules/07_vasoactive_drugs_ii_heart_failure.pdf` |
| 8 | Lipid lowering drugs | `modules/08_lipid_lowering_drugs.pdf` |
| 9 | Immunosuppression for solid organ transplantation | `modules/09_immunosuppression_for_solid_organ_transplantatio.pdf` |
| 10 | Nitric oxide | `modules/10_nitric_oxide.pdf` |
| 11 | Neuropharmacology I: drugs for movement disorders | `modules/11_neuropharmacology_i_drugs_for_movement_disorders.pdf` |
| 12 | Neuropharmacology III: anticonvulsants | `modules/12_neuropharmacology_iii_anticonvulsants.pdf` |
| 13 | Neuropharmacology II: anxiolytics and antidepressants | `modules/13_neuropharmacology_ii_anxiolytics_and_antidepress.pdf` |
| 14 | Antimicrobials I and II | `modules/14_antimicrobials_i_and_ii.pdf` |
| 15 | Chemotherapy I and II | `modules/15_chemotherapy_i_and_ii.pdf` |
| 16 | Opioids I and II | `modules/16_opioids_i_and_ii.pdf` |
