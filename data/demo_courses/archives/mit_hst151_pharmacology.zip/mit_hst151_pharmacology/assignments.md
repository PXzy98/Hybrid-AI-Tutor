# MIT HST.151 Principles of Pharmacology (Spring 2005): assignments

> Source: Principles of Pharmacology (Spring 2005), Carl Rosow, Gary Strichartz, and Carol Walsh, MIT OpenCourseWare. https://ocw.mit.edu/courses/hst-151-principles-of-pharmacology-spring-2005/pages/assignments/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

Students must complete three assignments in this class: a case discussion, a drug evaluation report, and a problem set.

### Case Discussion

#### General Guidelines

The student-led case discussions that follow are provided to cover some important topics in pharmacology which are either not addressed or dealt with only briefly in faculty lectures. Each case is based on a real incident, but many have been embellished to bring out useful points. We hope you will concentrate primarily on pharmacologic issues and not get bogged down on interesting clinical sidelights.

Each of these case discussions will be analyzed by 2 students, and each student will be expected to give an oral presentation for about 10 minutes: For example, the first presenter might cover the pharmacologic background of the case, and the second could then apply it to the specific clinical problem. The bibliographic search will be your responsibility - textbooks and review articles may suffice, but primary literature is sometimes necessary. Please meet me once after class to review the content and format of your presentation. Each student should prepare a clear, concise handout which does not exceed 2 pages. It can be a little longer if you need it, but take pity on your presbyopic Course Director and don’t use microscopic type! This material should be e-mailed to one of the TA’s at least 2 days before the presentation so it can be posted on the course Web site. If you have a PPT file, that can be posted as well. Ordinarily, I would prefer that you don’t use copies of Microsoft® PowerPoint slides as a handout. We will present the first case, so you all will have a clearer idea of what is expected.

These presentations may be used to satisfy part of the HST communication requirement, and this year I will give each student written feedback on style and clarity as well as content. Each pair of students **must** arrange to run through the presentation at least one day in advance with a TA (no run-through = no presentation!). The lectures and cases are closely scheduled, so we have to enforce the 20 minute limit.

We expect all students to attend and participate in the discussion for two reasons:

- It is a courtesy to your fellow students

- You will be responsible for this material on the exams(!)

Below is a list of the case topics:

- Organophosphate Poisoning

- Anticoagulation

- Ulcerative Colitis and Sulfasalazine

- Pheochromocytoma

- Asthma

- Poison Control

- Cocaine - MI

- Glaucoma

- Pharmacogenetics

- Hyperthyroidism

- Placental Transfer

- Gout

- Analgesia - Placebo Response

- Geriatric Pharmacology

- Antiemetics

- Acute Renal Failure

- Lithium Toxicity

- Alcohol

- Allergy

- Migraine

- Folate

- Oral Hypoglycemics

- Analgesia - Terminal Cancer

- Drug Abuse

 

Detailed description of Case Topics (PDF)

Following are several examples of student case discussion presentations. Files are courtesy of the respective authors, used with permission.

| TOPICS | STUDENTS | NOTES | SLIDES |

| Sulfasalazine | Paul Dieffenbach and Ali Shoeb | (PDF) | (PDF) |

| Oral Hypoglycemics | Lynn Punnoose and Erika Wagner | (PDF) | (PDF) |

### Drug Evaluation Report

The pharmacopoeia is constantly changing. Admittedly, some drugs, like morphine, aspirin and penicillin, seem destined to be with us forever. Nevertheless, it is very likely that many of the drugs you learn about today will be irrelevant in 15 years. Each of you will need to evaluate the literature on new drugs and decide whether it is reasonable to prescribe them in place of old ones. Some of you may need to make these decisions for hospital P and T (Pharmacy and Therapeutics, formulary) committees.

You will undoubtedly be “helped” in your evaluations by drug company representatives, full color ads (often aimed at your **patients**), and marketing studies with substantial built-in bias. (Many of these studies are not peer-reviewed and appear in journal supplements paid for by the manufacturer). You will also have some real cost constraints: remember, a new drug usually costs more - and sometimes a lot more - than what it replaces.

This exercise is intended to get you thinking about the utility, safety, and relative value of new drugs. Each student will be expected to complete a short paper dealing with a relatively new FDA-approved drug selected from the list on the next page. The paper should be **succinct** - about 5 pages long, with no more than 10 references. This paper will also count towards the HST communication requirement. We specifically want you to address the following questions:

- What are the “FDA-approved” and “unapproved” **indications** for this drug?

 

- What is the **mechanism** of its therapeutic effect? Is this drug a member of an established class, or is it a brand new form of therapy?

 

- What is the appropriate standard against which to compare it? Why? Is this **comparator** another drug, a surgical procedure, or …?

 

- What are the manufacturer’s claims for the drug? Do the data support any claims that it is **more effective** or **safer** than the comparator (be specific)? Are these data from properly designed trials and published in peer-reviewed journals?

 

- What is the *cost* to the patient (per treatment or per time period, if appropriate)? Do **you** think it is worth the price? Why?

Due date is on session 12.

| Suggested Drugs for Evaluation |

| balsalazide | irbesartan | rifapentine |

| basilixumab | lansoprazole | risedronate |

| benazepril | leflunomide | rivastigmine |

| beractant | lepirudin | rizatriptan |

| bivalirudin | levalbuterol | rosiglitazone |

| brinzolamide | levetiracetam | sermorelin |

| candesartan | lomefloxacin | sibutramine |

| caspofungin | meloxicam | sirolimus |

| cefdinir | meropenem | telmisartan |

| cerivastatin | mezlocillin | tenecteplase |

| cilostazol | miglitol | tiagabine |

| citalopram | mometasone | tirofiban |

| clopidogrel | moxifloxacin | tolterodine |

| colesevelam | naratriptan | tramadol |

| daclizumab | nateglinide | trandolapril |

| dofetilide | netilmicin | tyloxapol |

| entacapone | nizatidine | valdecoxib |

| eprosartan | olsalazine | valsartan |

| eptifibatide | oseltamavir | venlafaxine |

| etanercept | palivizumab | zafirlukast |

| famciclovir | pantoprazole | zaleplon |

| fenoterol | perindopril | zanamavir |

| fosinopril | quetiapine | zileuton |

| gatifloxacin | quinapril | ziprasidone |

| glatiramer acetate | rabeprazole | zolmitriptan |

| granisetron | raloxifene | zonisamide |

| indapamide | ramipril | |

| infliximab | repaglinide | |

### Problem Set

Problem Set (PDF)

Solution (PDF)
