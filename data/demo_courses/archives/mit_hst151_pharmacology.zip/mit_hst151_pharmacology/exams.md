# MIT HST.151 Principles of Pharmacology (Spring 2005): exams

> Source: Principles of Pharmacology (Spring 2005), Carl Rosow, Gary Strichartz, and Carol Walsh, MIT OpenCourseWare. https://ocw.mit.edu/courses/hst-151-principles-of-pharmacology-spring-2005/pages/exams/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

Midterm Exam (PDF)

Final Exam (PDF)
