# MIT HST.151 Principles of Pharmacology (Spring 2005): calendar

> Source: Principles of Pharmacology (Spring 2005), Carl Rosow, Gary Strichartz, and Carol Walsh, MIT OpenCourseWare. https://ocw.mit.edu/courses/hst-151-principles-of-pharmacology-spring-2005/pages/calendar/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| LEC # | TOPICS | INSTRUCTORS | KEY DATES |

| 1 | Introduction Receptors / Dose-Response | Dr. Carl Rosow Prof. Gary Strichartz | |

| 2 | Pharmacokinetics I Pharmacokinetics II | Prof. Carol Walsh Prof. Carol Walsh | |

| 3 | Interpreting Clinical Literature Cholinergic Pharmacology Case: Anticholinesterase | Harold Demonaco Prof. Gary Strichartz Faculty | |

| 4 | Drug Metabolism Pharmacogenetics Cases: Anticoagulation, Sulfasalazine | Dr. Mark Dershwitz Dr. Mark Dershwitz Students | |

| 5 | Autonomic Pharmacology I Autonomic Pharmacology II Cases: Pheochromocytoma, Asthma | Dr. Carl Rosow Dr. Carl Rosow Students | |

| 6 | Local Anesthetics Antidysrhythmics Cases: Poison Control, Cocaine | Prof. Gary Strichartz Dr. Jeremy Ruskin Students | |

| 7 | Pharmacokinetics III Antiinflammatory Drugs Case: Glaucoma | Prof. Robert Langer Dr. Michael Weinblatt Students | Problem set due |

| 8 | Vasoactive Drugs I Vasoactive Drugs II: Heart Failure Cases: Pharmacogenetics, Thyroid Disease | Prof. Keith Baker Prof. Keith Baker Students | |

| 9 | Lipid Lowering Drugs Cases: Placental Transfer, Gout | Dr. Robert Lees Students | |

| 10 | Antihistamines Immunosuppression for Solid Organ Transplantation Cases: Antiemetics, Geriatric Pharmacology | Dr. Mark Dershwitz Prof. Thomas Spitzer Students | |

| 11 | Midterm Exam Drug Development | Dr. Daniel Kohane | |

| 12 | Neuropharmacology I: Drugs for Movement Disorders Nitric Oxide Cases: Placebo, Renal Failure | Dr. David Standaert Dr. Warren Zapol Students | Drug evaluation due |

| 13 | Neuropharmacology II: Anxiolytics and Antidepressants Neuropharmacology III: Anticonvulsants Cases: Lithium, Alcohol | Dr. David Standaert Dr. David Standaert Students | |

| 14 | Antimicrobials I Antimicrobials II Cases: Drug Allergy, Migraines | Dr. Robert Rubin Dr. Robert Rubin Students | |

| 15 | Chemotherapy I Chemotherapy II Cases: Folate, Oral Hypoglycemics | Dr. Donald Kufe Dr. Donald Kufe Students | |

| 16 | Opioids I Opioids II Cases: Cancer - Analgesia, Drug Abuse | Dr. Carl Rosow Dr. Carl Rosow Students | |

| 17 | Final Exam | | |
