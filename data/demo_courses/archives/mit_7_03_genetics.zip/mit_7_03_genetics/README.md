# MIT 7.03: Genetics (Fall 2004)

Open course material used as a demo and test course of the Hybrid AI Tutor (course type `life_science`). See [../README.md](../README.md).

- **Source**: [https://ocw.mit.edu/courses/7-03-genetics-fall-2004/](https://ocw.mit.edu/courses/7-03-genetics-fall-2004/)
- **Author**: Chris Kaiser, Gerald Fink, and Leona Samson, MIT OpenCourseWare
- **License**: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Non-commercial use only; adaptations are shared under the same license.
- **Retrieved**: 2026-11-12
- **Changes**: files renamed and numbered as modules; web pages converted to Markdown with an attribution header. PDFs are unchanged.
- The authors and their institution do not endorse this project.

## Course-level documents

Uploaded to the course (not to a module): the syllabus and, where the course has them, the calendar, assignments and exams (questions only).

- `syllabus.md`
- `calendar.md`
- `assignments.md`
- `assignments/pset1.pdf`
- `assignments/pset2.pdf`
- `assignments/pset3.pdf`
- `assignments/pset4.pdf`
- `assignments/pset5.pdf`
- `assignments/pset6.pdf`
- `assignments/pset7.pdf`
- `exams.md`
- `exams/exam1_2004.pdf`
- `exams/exam2_2004.pdf`
- `exams/exam3_2004.pdf`

## Instructor only

Solutions and answer keys. **Never upload them as course material**: students would get the answers. They are kept to check generated quizzes.

- `instructor_only/assignments/pset1_ans.pdf`
- `instructor_only/assignments/pset2_ans.pdf`
- `instructor_only/assignments/pset3_ans.pdf`
- `instructor_only/assignments/pset4_ans.pdf`
- `instructor_only/assignments/pset5_ans.pdf`
- `instructor_only/assignments/pset6_ans.pdf`
- `instructor_only/assignments/pset7_ans.pdf`

## Modules

| Module | Title | File |
|---|---|---|
| 1 | Lecture 1: Physical Structure of the Gene | `modules/01_lecture_1_physical_structure_of_the_gene.pdf` |
| 2 | Lecture 2: The Complementation Test and Gene Function | `modules/02_lecture_2_the_complementation_test_and_gene_func.pdf` |
| 3 | Lecture 3: Mendelian Genetics | `modules/03_lecture_3_mendelian_genetics.pdf` |
| 4 | Lecture 4: Probability and Pedigrees | `modules/04_lecture_4_probability_and_pedigrees.pdf` |
| 5 | Lecture 5: Chromosomes and Sex Linkage | `modules/05_lecture_5_chromosomes_and_sex_linkage.pdf` |
| 6 | Lecture 6: Recombination and Genetic Maps | `modules/06_lecture_6_recombination_and_genetic_maps.pdf` |
| 7 | Lecture 7: Three-factor Crosses | `modules/07_lecture_7_three_factor_crosses.pdf` |
| 8 | Lecture 8: Tetrad Analysis | `modules/08_lecture_8_tetrad_analysis.pdf` |
| 9 | Lecture 9: Phage Genetics | `modules/09_lecture_9_phage_genetics.pdf` |
| 10 | Lecture 10: Gene Structure and DNA Analysis | `modules/10_lecture_10_gene_structure_and_dna_analysis.pdf` |
| 11 | Lecture 11: Mutations and Suppressors | `modules/11_lecture_11_mutations_and_suppressors.pdf` |
| 12 | Lecture 12: Bacterial Genetics: Transposition | `modules/12_lecture_12_bacterial_genetics_transposition.pdf` |
| 13 | Lecture 13: Bacterial Genetics: Transduction | `modules/13_lecture_13_bacterial_genetics_transduction.pdf` |
| 14 | Lecture 14: Complementation in Bacteria: Plasmids | `modules/14_lecture_14_complementation_in_bacteria_plasmids.pdf` |
| 15 | Lecture 15: Complementation in Bacteria: Recombinant DNA | `modules/15_lecture_15_complementation_in_bacteria_recombina.pdf` |
| 16 | Lecture 16: Prokaryotic Regulation: Negative Control | `modules/16_lecture_16_prokaryotic_regulation_negative_contr.pdf` |
| 17 | Lecture 17: Prokaryotic Regulation: Positive Control | `modules/17_lecture_17_prokaryotic_regulation_positive_contr.pdf` |
| 18 | Lecture 18: Prokaryotic Regulation: Regulatory Circuits | `modules/18_lecture_18_prokaryotic_regulation_regulatory_cir.pdf` |
| 19 | Lecture 19: Eukaryotic Genes and Genomes I | `modules/19_lecture_19_eukaryotic_genes_and_genomes_i.pdf` |
| 20 | Lecture 20: Eukaryotic Genes and Genomes II | `modules/20_lecture_20_eukaryotic_genes_and_genomes_ii.pdf` |
| 21 | Lecture 21: Eukaryotic Genes and Genomes III | `modules/21_lecture_21_eukaryotic_genes_and_genomes_iii.pdf` |
| 22 | Lecture 22: Eukaryotic Genes and Genomes IV | `modules/22_lecture_22_eukaryotic_genes_and_genomes_iv.pdf` |
| 23 | Lecture 23: Transgenes and Gene Targeting in Mice I | `modules/23_lecture_23_transgenes_and_gene_targeting_in_mice.pdf` |
| 24 | Lecture 24: Transgenes and Gene Targeting in Mice II | `modules/24_lecture_24_transgenes_and_gene_targeting_in_mice.pdf` |
| 25 | Lecture 25: Population Genetics: Hardy-Weinberg | `modules/25_lecture_25_population_genetics_hardy_weinberg.pdf` |
| 26 | Lecture 26: Population Genetics: Mutation and Selection | `modules/26_lecture_26_population_genetics_mutation_and_sele.pdf` |
| 27 | Lecture 27: Population Genetics: Inbreeding | `modules/27_lecture_27_population_genetics_inbreeding.pdf` |
| 28 | Lecture 28: Human Polymorphisms | `modules/28_lecture_28_human_polymorphisms.pdf` |
| 29 | Lectures 29-30: Statistical Evaluation of Linkage I and II | `modules/29_lectures_29_30_statistical_evaluation_of_linkage.pdf` |
| 30 | Lecture 31: Complex Traits | `modules/30_lecture_31_complex_traits.pdf` |
| 31 | Lecture 32: Chromosome Anomalies I | `modules/31_lecture_32_chromosome_anomalies_i.pdf` |
| 32 | Lecture 34: Genetics of Cancer I | `modules/32_lecture_34_genetics_of_cancer_i.pdf` |
| 33 | Lecture 35: Genetics of Cancer II | `modules/33_lecture_35_genetics_of_cancer_ii.pdf` |
