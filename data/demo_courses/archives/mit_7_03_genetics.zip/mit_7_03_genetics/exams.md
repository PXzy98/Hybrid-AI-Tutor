# MIT 7.03 Genetics (Fall 2004): exams

> Source: Genetics (Fall 2004), Chris Kaiser, Gerald Fink, and Leona Samson, MIT OpenCourseWare. https://ocw.mit.edu/courses/7-03-genetics-fall-2004/pages/exams/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

Exams listed in the table below cover material from the corresponding lecture sessions.

| lec # | exams |

| Lectures 1-10 | Exam I (PDF) |

| Lectures 11-18 | Exam II (PDF) |

| Lectures 19-30 | Exam III (PDF) |

| The final exam is comprehensive and covers material from the entire course with an emphasis on material from lectures 31-36. | Final Exam |
