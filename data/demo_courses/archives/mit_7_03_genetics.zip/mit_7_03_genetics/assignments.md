# MIT 7.03 Genetics (Fall 2004): assignments

> Source: Genetics (Fall 2004), Chris Kaiser, Gerald Fink, and Leona Samson, MIT OpenCourseWare. https://ocw.mit.edu/courses/7-03-genetics-fall-2004/pages/assignments/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

The first six problem sets are graded. The seventh problem set is for practice only and will not be graded. Assignments cover the topics discussed in the corresponding lecture sessions.

| LEC # | ASSIGNMENTs | SOLUTIONS |

| 1-5 | Problem Set 1 (PDF) | (PDF) |

| 6-9 | Problem Set 2 (PDF) | (PDF) |

| 11-15 | Problem Set 3 (PDF) | (PDF) |

| 16-19 | Problem Set 4 (PDF) | (PDF) |

| 20-24 | Problem Set 5 (PDF) | (PDF) |

| 25-30 | Problem Set 6 (PDF) | (PDF) |

| 31-35 | Problem Set 7 (PDF) | (PDF) |

The teaching staff also recommends that students practice on problem sets and exams from previous years. An archive of past assignments and exams can be found in the study materials section of this course site.
