# MIT 6.006 Introduction to Algorithms (Spring 2020): assignments

> Source: Introduction to Algorithms (Spring 2020), Erik Demaine, Jason Ku, and Justin Solomon, MIT OpenCourseWare. https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/pages/assignments/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| Problem Sets | Solutions |

| Problem Set 0 Questions (PDF) Problem Set 0 Template (ZIP) This file contains: 2 .py files and 2 .tex files. | Problem Set 0 Solutions (PDF) |

| Problem Set 1 Questions (PDF) Problem Set 1 Template (ZIP) This file contains: 2 .py files and 2 .tex files. | Problem Set 1 Solutions (PDF) |

| Problem Set 2 Questions (PDF) Problem Set 2 Template (ZIP) This file contains: 2 .py files and 2 .tex files. | Problem Set 2 Solutions (PDF) |

| Problem Set 3 Questions (PDF) Problem Set 3 Template (ZIP) This file contains: 2 .py files and 2 .tex files. | Problem Set 3 Solutions (PDF) |

| Problem Set 4 Questions (PDF) Problem Set 4 Template (ZIP) This file contains: 4 .py files and 2 .tex files. | Problem Set 4 Solutions (PDF) |

| Problem Set 5 Questions (PDF) Problem Set 5 Template (ZIP) This file contains: 2 .py files and 2 .tex files. | Problem Set 5 Solutions (PDF) |

| Problem Set 6 Questions (PDF) Problem Set 6 Template (ZIP) This file contains: | Problem Set 6 Solutions (PDF) |

| Problem Set 7 Questions (PDF) Problem Set 7 Template (ZIP) This file contains: 2 .py files and 2 .tex files. | Problem Set 7 Solutions (PDF) |

| Problem Set 8 Questions (PDF) Problem Set 8 Template (ZIP) This file contains: 2 .tex files. | Problem Set 8 Solutions (PDF) |
