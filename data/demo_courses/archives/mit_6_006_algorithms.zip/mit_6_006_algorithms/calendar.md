# MIT 6.006 Introduction to Algorithms (Spring 2020): calendar

> Source: Introduction to Algorithms (Spring 2020), Erik Demaine, Jason Ku, and Justin Solomon, MIT OpenCourseWare. https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/pages/calendar/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

Lectures occured on Tuesdays and Thursdays. Recitations took place on Wednesdays and Fridays. Optional problem sessions were held on Fridays. 

| Week | Lectures | Recitations | Problem Sessions | Key Dates |

| 1 | Lecture 1: Introduction Lecture 2: Data Structures | Recitation 1 Recitation 2 | Problem Session 1 | Problem Set 0 Due |

| 2 | Lecture 3: Sorting Lecture 4: Hashing | Recitation 3 Recitation 4 | Problem Session 2 | Problem Set 1 Due |

| 3 | Lecture 5: Linear Sorting | Recitation 5 | Problem Session 3 | Problem Set 2 Due |

| 4 | Lecture 6: Binary Trees, Part 1 Lecture 7: Binary Trees, Part 2: AVL | Recitation 6 Recitation 7 | Problem Session 4 | Problem Set 3 Due |

| 5 | Lecture 8: Binary Heaps Lecture 9: Breadth-First Search | Recitation 8 Recitation 9 | Quiz 1 Review | Problem Set 4 Due Quiz 1 Review |

| 6 | Lecture 10: Depth-First Search Lecture 11: Weighted Shortest Paths | Recitation 10 Recitation 11 | Problem Session 5 | |

| 7 | Lecture 12: Bellman-Ford | Recitation 12 | Problem Session 6 | Problem Set 5 Due Quiz 1 |

| 8 | Lecture 13: Dijkstra’s Algorithm Lecture 14: Johnson’s Algorithm | Recitation 13 Recitation 14 | Problem Session 7 | Problem Set 6 Due Quiz 2 Review |

| 9 | Lecture 15: Dynamic Programming, Part 1: Recursive Algorithms Lecture 16: Dynamic Programming, Part 2: Subproblems | Recitation 15 Recitation 16 | Problem Session 8 | |

| 10 | Lecture 17: Dynamic Programming, Part 3: APSP, Parens, Piano | Recitation 17 | No problem sessions | Problem Set 7 Due Quiz 2 |

| 11 | Lecture 18: Dynamic Programming, Part 4: Pseudopolynomials Lecture 19: Complexity | Recitation 18 Recitation 19 | Problem Session 9 | Problem Set 8 Due Quiz 3 Review |

| 12 | Lecture 20: Course Review | Recitation 20 | No problem sessions | Quiz 3 |

| 13 | Lecture 21: Algorithms—Next Steps | No recitations | No problem sessions | |

| 14 | Final Exam |
