# MIT 6.006 Introduction to Algorithms (Spring 2020): quizzes

> Source: Introduction to Algorithms (Spring 2020), Erik Demaine, Jason Ku, and Justin Solomon, MIT OpenCourseWare. https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/pages/quizzes/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| Quiz Review | Quiz |

| Quiz 1 Review (PDF) Quiz 1 Review Solutions (PDF) | Quiz 1 (PDF) Quiz 1 Solutions (PDF) |

| Quiz 2 Review (PDF) Quiz 2 Review Solutions (PDF) | Quiz 2 (PDF) Quiz 2 Solutions (PDF) |

| Quiz 3 Review (PDF) Quiz 3 Review Solutions (PDF) | Quiz 3 (PDF) Quiz 3 Solutions (PDF) |

| No reviews | Final Exam (PDF) Final Exam Solutions (PDF) |
