# MIT 6.006: Introduction to Algorithms (Spring 2020)

Open course material used as a demo and test course of the Hybrid AI Tutor (course type `ece`). See [../README.md](../README.md).

- **Source**: [https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/](https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/)
- **Author**: Erik Demaine, Jason Ku, and Justin Solomon, MIT OpenCourseWare
- **License**: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Non-commercial use only; adaptations are shared under the same license.
- **Retrieved**: 2026-11-12
- **Changes**: files renamed and numbered as modules; web pages converted to Markdown with an attribution header. PDFs are unchanged.
- The authors and their institution do not endorse this project.

## Course-level documents

Uploaded to the course (not to a module): the syllabus and, where the course has them, the calendar, assignments and exams (questions only).

- `syllabus.md`
- `calendar.md`
- `assignments.md`
- `assignments/problem_set_0.pdf`
- `assignments/problem_set_1.pdf`
- `assignments/problem_set_2.pdf`
- `assignments/problem_set_3.pdf`
- `assignments/problem_set_4.pdf`
- `assignments/problem_set_5.pdf`
- `assignments/problem_set_6.pdf`
- `assignments/problem_set_7.pdf`
- `assignments/problem_set_8.pdf`
- `quizzes.md`
- `quizzes/final_exam.pdf`
- `quizzes/quiz_1.pdf`
- `quizzes/quiz_2.pdf`
- `quizzes/quiz_3.pdf`
- `quizzes/quiz_1_review.pdf`
- `quizzes/quiz_2_review.pdf`
- `quizzes/quiz_3_review.pdf`

## Instructor only

Solutions and answer keys. **Never upload them as course material**: students would get the answers. They are kept to check generated quizzes.

- `instructor_only/assignments/problem_set_0_solutions.pdf`
- `instructor_only/assignments/problem_set_1_solutions.pdf`
- `instructor_only/assignments/problem_set_2_solutions.pdf`
- `instructor_only/assignments/problem_set_3_solutions.pdf`
- `instructor_only/assignments/problem_set_4_solutions.pdf`
- `instructor_only/assignments/problem_set_5_solutions.pdf`
- `instructor_only/assignments/problem_set_6_solutions.pdf`
- `instructor_only/assignments/problem_set_7_solutions.pdf`
- `instructor_only/assignments/problem_set_8_solutions.pdf`
- `instructor_only/quizzes/final_exam_solutions.pdf`
- `instructor_only/quizzes/quiz_1_solutions.pdf`
- `instructor_only/quizzes/quiz_2_solutions.pdf`
- `instructor_only/quizzes/quiz_3_solutions.pdf`
- `instructor_only/quizzes/quiz_1_review_solutions.pdf`
- `instructor_only/quizzes/quiz_2_review_solutions.pdf`
- `instructor_only/quizzes/quiz_3_review_solutions.pdf`

## Modules

| Module | Title | File |
|---|---|---|
| 1 | Lecture 1: Introduction | `modules/01_lecture_1_introduction.pdf` |
| 2 | Lecture 2: Data Structures | `modules/02_lecture_2_data_structures.pdf` |
| 3 | Lecture 3: Sorting | `modules/03_lecture_3_sorting.pdf` |
| 4 | Lecture 4: Hashing | `modules/04_lecture_4_hashing.pdf` |
| 5 | Lecture 5: Linear Sorting | `modules/05_lecture_5_linear_sorting.pdf` |
| 6 | Lecture 6: Binary Trees, Part 1 | `modules/06_lecture_6_binary_trees_part_1.pdf` |
| 7 | Lecture 7: Binary Trees, Part 2: AVL | `modules/07_lecture_7_binary_trees_part_2_avl.pdf` |
| 8 | Lecture 8: Binary Heaps | `modules/08_lecture_8_binary_heaps.pdf` |
| 9 | Lecture 9: Breadth-First Search | `modules/09_lecture_9_breadth_first_search.pdf` |
| 10 | Lecture 10: Depth-First Search | `modules/10_lecture_10_depth_first_search.pdf` |
| 11 | Lecture 11: Weighted Shortest Paths | `modules/11_lecture_11_weighted_shortest_paths.pdf` |
| 12 | Lecture 12: Bellman-Ford | `modules/12_lecture_12_bellman_ford.pdf` |
| 13 | Lecture 13: Dijkstra's Algorithm | `modules/13_lecture_13_dijkstra_s_algorithm.pdf` |
| 14 | Lecture 14: Johnson's Algorithm | `modules/14_lecture_14_johnson_s_algorithm.pdf` |
| 15 | Lecture 15: Recursive Algorithms | `modules/15_lecture_15_recursive_algorithms.pdf` |
| 16 | Lecture 17: Dynamic Programming, Part 3 | `modules/16_lecture_17_dynamic_programming_part_3.pdf` |
| 17 | Lecture 18: Pseudopolynomial | `modules/17_lecture_18_pseudopolynomial.pdf` |
| 18 | Lecture 19: Complexity | `modules/18_lecture_19_complexity.pdf` |
| 19 | Lecture 20: Course Review | `modules/19_lecture_20_course_review.pdf` |
