# MIT 6.006 Introduction to Algorithms (Spring 2020): syllabus

> Source: Introduction to Algorithms (Spring 2020), Erik Demaine, Jason Ku, and Justin Solomon, MIT OpenCourseWare. https://ocw.mit.edu/courses/6-006-introduction-to-algorithms-spring-2020/pages/syllabus/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

### Class Meeting Times

Lectures: 1 hr / session; 2 sessions / week

Recitations: 1 hr / session; 2 sessions / week

### Prerequisites

- *6.0001 Introduction to Computer Science and Programming in Python*:  Basic experience programming in Python 3.

- *6.042J Mathematics for Computer Science*: Basic knowledge of discrete mathematics: set theory, relations and logic, combinatorics, proofs, recursion, number theory, graph theory, and probability.

We strongly caution against taking 6.006 before having fulfilled the listed prerequisites. We will evaluate your understanding of the prerequisite material via a short Problem Set 0 assignment. All students must submit this evaluation, regardless of prerequisite status. We will assign each submission a letter grade. If you receive a C or below on the assignment, you will need to meet with a staff member to review your performance before you will be allowed to take the class. We will not grade any other assignments from you until a good faith attempt of Problem Set 0 has been submitted. The grade for this assignment will NOT affect your final grade in the class, but turning it in is required for taking this class.

### Course Description

This is an introductory course covering elementary data structures (dynamic arrays, heaps, balanced binary search trees, hash tables) and algorithmic approaches to solve classical problems (sorting, graph searching, dynamic programming). Introduction to mathematical modeling of computational problems, as well as common algorithms, algorithmic paradigms, and data structures used to solve these problems. Emphasizes the relationship between algorithms and programming, and introduces basic performance measures and analysis techniques for these problems.

### Textbooks

Written course material will be distributed via notes from lectures and recitations. An additional useful reference is Buy at MIT Press *Introduction to Algorithms* by Cormen, Leiserson, Rivest, and Stein (Third Edition, MIT Press) ISBN: 9780262033848, commonly known as *CLRS*, though this text is not required for the course.

### Grading

| Assignments | Percentages |

| Quiz 1 | 20% |

| Quiz 2 | 15% |

| Quiz 3 | 10% |

| Final Exam | 35% |

| Problem Sets | 18% |

| Recitation | 2% |
