# MIT 6.002 Circuits and Electronics (Spring 2007): exams

> Source: Circuits and Electronics (Spring 2007), Anant Agarwal, MIT OpenCourseWare. https://ocw.mit.edu/courses/6-002-circuits-and-electronics-spring-2007/pages/exams/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

This section contains the current semester’s exams as well as previous exams that were provided to students for practice.

| YEARS | EXAMS |

| Spring 2007 | Quiz 1 (PDF) |

| Spring 2007 | Quiz 2 (PDF) |

| Spring 2007 | Final (PDF - 1.5 MB) |

| Fall 2006 | Quiz 1 (PDF) |

| Fall 2004 | Quiz 2 (PDF) |

| Spring 2004 | Quiz 1 (PDF) |

| Spring 2004 | Quiz 2 (PDF) |

| Fall 2003 | Quiz 1 (PDF) |

| Fall 2000 | Final (PDF) |
