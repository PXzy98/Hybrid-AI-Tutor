# MIT 6.002 Circuits and Electronics (Spring 2007): calendar

> Source: Circuits and Electronics (Spring 2007), Anant Agarwal, MIT OpenCourseWare. https://ocw.mit.edu/courses/6-002-circuits-and-electronics-spring-2007/pages/calendar/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

The calendar provides information on the course’s lecture (L), recitation (R), and quiz (Q) sessions.

| SES # | TOPICS | KEY DATES |

| L1 | Lumped abstraction relationship to physics, KVL, KCL | Lab 0 out |

| R1 | KVL, KCL resistive network analysis | |

| L2 | KVL, KCL example, nodal analysis | Homework 1 out |

| R2 | Nodal analysis, examples | |

| L3 | Linearity, superposition, Thevenin’s equivalences | Lab 0 due 1 day before L3 |

| R3 | Thevenin and Norton equivalences | |

| L4 | Digital abstraction | Homework 2 out |

| R4 | Boolean logic, comb. gates review, examples | Homework 1 due |

| R4a | Digital logic, gates, examples | Lab 1 out |

| L5 | MOS switch, S and SR model, MOS gate design | Homework 3 out |

| R5 | MOS switch resistor (SR) model (cont.) | Homework 2 due |

| L6 | Nonlinear resistors, networks | |

| R6 | Static power in dig ckts, nonlinear resistors, examples | |

| L7 | Nonlinear resistors, small signal analysis | Homework 4 out |

| R7 | Nonlinear resistors, small signal examples | Homework 3 due |

| L8 | Dependent sources, analog amplification | |

| R8 | Dependent sources, amplifiers, operating point analysis, biasing | Lab 1 due |

| L9 | MOS SCS model and MOS amplifier | Homework 5 out |

| R9 | Review MOS SCS model, MOS ckts, MOS amplifier | Homework 4 due |

| Q1 | Quiz 1 (evening) | |

| R9a | MOS amplifier review | |

| L10 | Amplifier large signal analysis | Homework 6 out |

| R10 | Review 3-term device representations, amplifier input-output curves | Homework 5 due |

| L11 | Amplifier small signal analysis | Lab 2 out |

| R11 | Amplifier small signal analysis examples | |

| L12 | Amplifier small signal circuit models | Homework 7 out |

| R12 | Amplifier small signal circuit models and analysis examples | Homework 6 due |

| L13 | Capacitors, first order circuits, examples | |

| R13 | Inductors and their physics, first order step response, examples | |

| L14 | Intuitive analysis of first order systems, examples | Homework 8 out |

| R14 | Ramp, step, impulse, superposition | Homework 7 due |

| L15 | Digital memory, state | Lab 3 out |

| R15 | Impulse response examples, digital memory arrays | Lab 2 due |

| L16 | Transients in second order systems | Homework 9 out |

| R16 | First order examples Second order examples | Homework 8 due |

| R17 | Second order examples Second order systems with damping | |

| L17 | Second order systems with damping, intuitive analysis | Homework 10 out |

| R18 | Damped second order system examples Preview of frequency response | Homework 9 due |

| L18 | Sinusoidal steady state analysis, frequency response | Lab 4 out |

| Q2 | Quiz 2 (evening) | |

| L19 | Impedance methods | Homework 11/12 out |

| R19 | Review of impedance methods and examples | Homework 10 due |

| L20 | Filters, Q factor, radio tuner | |

| R20 | Time and frequency domain responses, Q | Lab 3 due |

| L21 | Op-amp abstraction, concept of feedback, noninverting amplifier | |

| R21 | Op-amp abstraction, examples and review, inverting amplifier | |

| L22 | Multiple inputs and superposition, integrators, differentiators | |

| R22 | First and second order op-amp filters | |

| L23 | Op-amp abstraction, feedback, stability, oscillators, clocking | |

| R23 | Special op-amp circuits | Lab 4 due Homework 11/12 due |

| L24 | Energy and power | |

| R24 | Examples, CMOS, energy and power | |

| L25 | Breaking the abstraction barrier | |
