# MIT 6.002 Circuits and Electronics (Spring 2007): assignments

> Source: Circuits and Electronics (Spring 2007), Anant Agarwal, MIT OpenCourseWare. https://ocw.mit.edu/courses/6-002-circuits-and-electronics-spring-2007/pages/assignments/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

Homework 1 (PDF)

Homework 2 (PDF)

Homework 3 (PDF)

Homework 4 (PDF)

Homework 5 (PDF)

Homework 6 (PDF)

Homework 7 (PDF)

Homework 8 (PDF)

Homework 9 (PDF)

Homework 10 (PDF)

Homework 11 (PDF)
