# MIT 6.002: Circuits and Electronics (Spring 2007)

Open course material used as a demo and test course of the Hybrid AI Tutor (course type `ece`). See [../README.md](../README.md).

- **Source**: [https://ocw.mit.edu/courses/6-002-circuits-and-electronics-spring-2007/](https://ocw.mit.edu/courses/6-002-circuits-and-electronics-spring-2007/)
- **Author**: Anant Agarwal, MIT OpenCourseWare
- **License**: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Non-commercial use only; adaptations are shared under the same license.
- **Retrieved**: 2026-11-12
- **Changes**: files renamed and numbered as modules; web pages converted to Markdown with an attribution header. PDFs are unchanged.
- The authors and their institution do not endorse this project.

## Course-level documents

Uploaded to the course (not to a module): the syllabus and, where the course has them, the calendar, assignments and exams (questions only).

- `syllabus.md`
- `calendar.md`
- `assignments.md`
- `assignments/homework_1.pdf`
- `assignments/homework_10.pdf`
- `assignments/homework_11.pdf`
- `assignments/homework_2.pdf`
- `assignments/homework_3.pdf`
- `assignments/homework_4.pdf`
- `assignments/homework_5.pdf`
- `assignments/homework_6.pdf`
- `assignments/homework_7.pdf`
- `assignments/homework_8.pdf`
- `assignments/homework_9.pdf`
- `exams.md`
- `exams/final_exam_fall_2000.pdf`
- `exams/final_exam_spring_2007.pdf`
- `exams/quiz_1_fall_2003.pdf`
- `exams/quiz_1_fall_2006.pdf`
- `exams/quiz_1_spring_2004.pdf`
- `exams/quiz_1_spring_2007.pdf`
- `exams/quiz_2_fall_2004.pdf`
- `exams/quiz_2_spring_2004.pdf`
- `exams/quiz_2_spring_2007.pdf`

## Instructor only

None.


## Modules

| Module | Title | File |
|---|---|---|
| 1 | Lecture 1: Introduction and lumped abstraction | `modules/01_lecture_1_introduction_and_lumped_abstraction.pdf` |
| 2 | Lecture 2: Basic circuit analysis method | `modules/02_lecture_2_basic_circuit_analysis_method.pdf` |
| 3 | Lecture 3: Superposition, Thévenin and Norton | `modules/03_lecture_3_superposition_th_venin_and_norton.pdf` |
| 4 | Lecture 4: The digital abstraction | `modules/04_lecture_4_the_digital_abstraction.pdf` |
| 5 | Lecture 5: Inside the digital gate | `modules/05_lecture_5_inside_the_digital_gate.pdf` |
| 6 | Lecture 6: Nonlinear analysis | `modules/06_lecture_6_nonlinear_analysis.pdf` |
| 7 | Lecture 7: Incremental analysis | `modules/07_lecture_7_incremental_analysis.pdf` |
| 8 | Lecture 8: Dependent sources and amplifiers | `modules/08_lecture_8_dependent_sources_and_amplifiers.pdf` |
| 9 | Lecture 9: MOSFET amplifier large signal analysis | `modules/09_lecture_9_mosfet_amplifier_large_signal_analysis.pdf` |
| 10 | Lecture 10: Amplifiers - small signal model | `modules/10_lecture_10_amplifiers_small_signal_model.pdf` |
| 11 | Lecture 11: Small signal circuits | `modules/11_lecture_11_small_signal_circuits.pdf` |
| 12 | Lecture 12: Capacitors and first-order systems | `modules/12_lecture_12_capacitors_and_first_order_systems.pdf` |
| 13 | Lecture 13: Digital circuit speed | `modules/13_lecture_13_digital_circuit_speed.pdf` |
| 14 | Lecture 14: State and memory | `modules/14_lecture_14_state_and_memory.pdf` |
| 15 | Lecture 15: Second-order systems | `modules/15_lecture_15_second_order_systems.pdf` |
| 16 | Lecture 15b: Damped Second-order systems | `modules/16_lecture_15b_damped_second_order_systems.pdf` |
| 17 | Lecture 16: Sinusoidal steady state | `modules/17_lecture_16_sinusoidal_steady_state.pdf` |
| 18 | Lecture 17: The impedance model | `modules/18_lecture_17_the_impedance_model.pdf` |
| 19 | Lecture 18: Filters | `modules/19_lecture_18_filters.pdf` |
| 20 | Lecture 19: The operational amplifier abstraction | `modules/20_lecture_19_the_operational_amplifier_abstraction.pdf` |
| 21 | Lecture 20: Operational amplifier circuits | `modules/21_lecture_20_operational_amplifier_circuits.pdf` |
| 22 | Lecture 21: Op-amps positive feedback | `modules/22_lecture_21_op_amps_positive_feedback.pdf` |
| 23 | Lecture 22: Energy and power | `modules/23_lecture_22_energy_and_power.pdf` |
| 24 | Lecture 23: Energy, CMOS | `modules/24_lecture_23_energy_cmos.pdf` |
| 25 | Lecture 25: Violating the abstraction barrier | `modules/25_lecture_25_violating_the_abstraction_barrier.pdf` |
