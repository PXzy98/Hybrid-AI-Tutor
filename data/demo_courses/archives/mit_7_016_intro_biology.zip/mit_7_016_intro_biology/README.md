# MIT 7.016: Introductory Biology (Fall 2018)

Open course material used as a demo and test course of the Hybrid AI Tutor (course type `life_science`). See [../README.md](../README.md).

- **Source**: [https://ocw.mit.edu/courses/7-016-introductory-biology-fall-2018/](https://ocw.mit.edu/courses/7-016-introductory-biology-fall-2018/)
- **Author**: Barbara Imperiali, Adam Martin, and Debra Mauzy-Melitz, MIT OpenCourseWare
- **License**: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Non-commercial use only; adaptations are shared under the same license.
- **Retrieved**: 2026-11-12
- **Changes**: files renamed and numbered as modules; web pages converted to Markdown with an attribution header. PDFs are unchanged.
- The authors and their institution do not endorse this project.

## Course-level documents

Uploaded to the course (not to a module): the syllabus and, where the course has them, the calendar, assignments and exams (questions only).

- `syllabus.md`
- `calendar.md`
- `assignments.md`
- `assignments/assignment_1.pdf`
- `assignments/assignment_2.pdf`
- `assignments/assignment_3.pdf`
- `assignments/assignment_4.pdf`
- `assignments/assignment_5.pdf`
- `assignments/assignment_6.pdf`
- `exams.md`
- `exams/exam_1.pdf`
- `exams/exam_2.pdf`
- `exams/exam_3.pdf`

## Instructor only

Solutions and answer keys. **Never upload them as course material**: students would get the answers. They are kept to check generated quizzes.

- `instructor_only/assignments/assignment_1_solutions.pdf`
- `instructor_only/assignments/assignment_2_solutions.pdf`
- `instructor_only/assignments/assignment_3_solutions.pdf`
- `instructor_only/assignments/assignment_4_solutions.pdf`
- `instructor_only/assignments/assignment_5_solutions.pdf`
- `instructor_only/assignments/assignment_6_solutions.pdf`
- `instructor_only/exams/exam_1_solutions.pdf`
- `instructor_only/exams/exam_2_solutions.pdf`
- `instructor_only/exams/exam_3_solutions.pdf`

## Modules

| Module | Title | File |
|---|---|---|
| 1 | Recitation 1 | `modules/01_recitation_1.pdf` |
| 2 | Recitation 2 | `modules/02_recitation_2.pdf` |
| 3 | Recitation 3 | `modules/03_recitation_3.pdf` |
| 4 | Recitation 4 | `modules/04_recitation_4.pdf` |
| 5 | Recitation 5 | `modules/05_recitation_5.pdf` |
| 6 | Recitation 6 | `modules/06_recitation_6.pdf` |
| 7 | Recitation 7 | `modules/07_recitation_7.pdf` |
| 8 | Recitation 8 | `modules/08_recitation_8.pdf` |
| 9 | Recitation 9 | `modules/09_recitation_9.pdf` |
| 10 | Recitation 10 | `modules/10_recitation_10.pdf` |
| 11 | Recitation 11 | `modules/11_recitation_11.pdf` |
| 12 | Recitation 12 | `modules/12_recitation_12.pdf` |
| 13 | Recitation 13 | `modules/13_recitation_13.pdf` |
| 14 | Recitation 14 | `modules/14_recitation_14.pdf` |
| 15 | Recitation 15 | `modules/15_recitation_15.pdf` |
| 16 | Recitation 16 | `modules/16_recitation_16.pdf` |
| 17 | Recitation 17 | `modules/17_recitation_17.pdf` |
| 18 | Recitation 18 | `modules/18_recitation_18.pdf` |
| 19 | Recitation 19 | `modules/19_recitation_19.pdf` |
| 20 | Recitation 20 | `modules/20_recitation_20.pdf` |
| 21 | Recitation 21 | `modules/21_recitation_21.pdf` |
| 22 | Recitation 22 | `modules/22_recitation_22.pdf` |
