# MIT 7.016 Introductory Biology (Fall 2018): calendar

> Source: Introductory Biology (Fall 2018), Barbara Imperiali, Adam Martin, and Debra Mauzy-Melitz, MIT OpenCourseWare. https://ocw.mit.edu/courses/7-016-introductory-biology-fall-2018/pages/calendar/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| LEC # | TOPICS | KEY DATES |

| 1 | Welcome; Introduction and course organization | |

| 2 | Chemical bonding and molecular interactions; Lipids and membranes | |

| 3 | Structures of amino acids, peptides and proteins | |

| 4 | Enzymes and metabolism | |

| 5 | Carbohydrates and glycoproteins | Problem set 1 due |

| 6 | Nucleic acids | |

| 7 | Replication | |

| 8 | Transcription | |

| 9 | Chromatin remodeling and splicing | |

| 10 | Translation | Problem set 2 due |

| 11 | Cells, the simplest functional units | |

| Exam 1 (Covering Lectures 1–10) |

| 12 | Genetics 1—Cell division and segregating genetic material | |

| 13 | Genetics 2—Rules of inheritance | |

| 14 | Genetics 3—Linkage, crossing over | Problem set 3 due |

| 15 | Genetics 4—The power of model organisms in biological discovery | |

| 16 | Recombinant DNA, cloning, and editing | |

| 17 | Genomes and DNA sequencing | |

| 18 | SNPs and human genetics | Problem set 4 due |

| Exam 2 (Covering Lectures 11–17) |

| 19 | Cell trafficking and protein localization | |

| 20 | Cell signaling 1—Overview | |

| 21 | Cell signaling 2—Examples | |

| 22 | Neurons, action potential, and optogenetics | |

| 23 | Cell cycle and checkpoints | |

| 24 | Stem cells, apoptosis, and tissue homeostasis | |

| 25 | Cancer 1 | Problem set 5 due |

| 26 | Cancer 2 | |

| Exam 3 (Covering Lectures 18–25) |

| 27 | Visualizing life—Dyes and stains | |

| 28 | Visualizing life—Fluorescent proteins | |

| 29 | Cell imaging techniques | |

| 30 | Immunology 1—Diversity, specificity, and B cells | |

| 31 | Immunology 2—Memory, T cells, and autoimmunity | News brief proposal due |

| 32 | Infectious disease, viruses, and bacteria | |

| 33 | Bacteria and antibiotic resistance | |

| 34 | Viruses and anti-viral resistance | Problem set due |

| 35 | Reproductive cloning and embryonic stem cells | |

| 36 | “In the news” | |

| Final Exam (Covering Lectures 1–36) |
