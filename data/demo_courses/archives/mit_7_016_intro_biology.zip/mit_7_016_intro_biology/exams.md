# MIT 7.016 Introductory Biology (Fall 2018): exams

> Source: Introductory Biology (Fall 2018), Barbara Imperiali, Adam Martin, and Debra Mauzy-Melitz, MIT OpenCourseWare. https://ocw.mit.edu/courses/7-016-introductory-biology-fall-2018/pages/exams/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| EXAMS | SOLUTIONS |

| Exam 1 (PDF) | Solution to Exam 1 (PDF) |

| Exam 2 (PDF) | Solution to Exam 2 (PDF) |

| Exam 3 (PDF) | Solution to Exam 3 (PDF) |
