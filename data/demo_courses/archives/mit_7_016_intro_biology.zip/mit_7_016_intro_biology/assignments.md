# MIT 7.016 Introductory Biology (Fall 2018): assignments

> Source: Introductory Biology (Fall 2018), Barbara Imperiali, Adam Martin, and Debra Mauzy-Melitz, MIT OpenCourseWare. https://ocw.mit.edu/courses/7-016-introductory-biology-fall-2018/pages/assignments/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

| Problem sets | SOLUTIONS |

| Problem Set 1 (PDF) | Solution to Problem Set 1 (PDF) |

| Problem Set 2 (PDF) | Solution to Problem Set 2 (PDF) |

| Problem Set 3 (PDF) | Solution to Problem Set 3 (PDF) |

| Problem Set 4 (PDF) | Solution to Problem Set 4 (PDF) |

| Problem Set 5 (PDF) | Solution to Problem Set 5 (PDF) |

| Problem Set 6 (PDF) | Solution to Problem Set 6 (PDF) |

### News Brief or Project

This assignment will be different from the “standard Problem sets”. For this assignment, you will prepare either a news brief or a “hands-on” project and is worth 4% of your grade.

The news brief should be a 1–2 page summary of an exciting recent development in the life sciences with content that colleagues in 7.016 will be interested in. There should be at least one paragraph on the background/significance and one paragraph detailing the innovation and its applications and one to two figures that you make specifically to describe the main news/innovation. Please do not directly copy figures from the source—try making your own!

You can check out the following links to identify a topic for your proposal:

*The Scientist*

*ASBMB Today*

Or you can find a topic in the popular press. You also have two other options besides the news brief.

1. You can refer to the Protein Data Bank (PDB) and pick the structure of a protein to print on a 3D printer (you can find out how to do this using the coordinates of the protein structure on the web). Then you should submit the printed model along with a description of the protein and its physiological function.

2. You can develop a classroom demo of topoisomerase. Prof. Imperiali showed a demo made with blue and yellow ethernet cables in class. The demo should be much better (!) and should show the actual function of topoisomerase in relieving supercoiling by cutting and rejoining the DNA strands.
