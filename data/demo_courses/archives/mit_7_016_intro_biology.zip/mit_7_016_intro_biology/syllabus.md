# MIT 7.016 Introductory Biology (Fall 2018): syllabus

> Source: Introductory Biology (Fall 2018), Barbara Imperiali, Adam Martin, and Debra Mauzy-Melitz, MIT OpenCourseWare. https://ocw.mit.edu/courses/7-016-introductory-biology-fall-2018/pages/syllabus/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation removed.

### Course Meeting Times

Lectures: 3 sessions / week, 1 hour / session

Recitations: 2 sessions / week, 1 hour / session

### Prerequisites

There are no formal prerequisites for this course, but we do presuppose high-school-level biology and chemistry (especially familiarity with the fundamental aspects of chemical structure).

Before taking this course, you may want to review *Pre-7.01 Getting up to Speed in Biology*, a self-paced course designed to help prepare students for their first college-level biology class.

### Textbook

The required textbook is: Sadava, D. E., D. M. Hillis, et al. *Life: The Science of Biology*. 11th ed. W. H. Freeman, 2016. ISBN: 9781319145446.

### Recitations

Regular weekly attendance is expected. Each recitation section meets twice per week for 50 minutes.

### Assignments

There will be six graded problem sets, but only your best five problem set scores will be used in determining your grade. While general discussions and collaboration on the problem sets are appropriate, detailed discussion of specific solutions or sharing of answers is a violation of the trust placed in all students in the class, each of whom is expected to produce their own unique set of answers. Students who copy problem sets or allow their answers to be copied will be assigned a zero for that problem set, and may be assigned a zero for all the problem sets.

In addition to the five problem sets, students will have a sixth assignment in which they will choose to prepare either a news brief or a “hands-on” project, worth 4% of their final grade. Please refer to the Assignments section for more detail.

### Exams

There will be three 50-minute exams given during the term and a comprehensive final given during the finals week. The final exam will be a 3-hour cumulative exam covering the entire course.

### Grading

Your overall course grade will depend on the following components:

| ACTIVITIES | TOTAL POINTS | % OF Overall GRADES |

| Three Term Exams (100 points each) | 300 | 51% |

| Five Problem Sets (20 points each) | 100 | 15% |

| News Brief Proposal | 20 | 4% |

| Comprehensive Final Exam | 200 | 30% |

| Total | 620 | 100% |
