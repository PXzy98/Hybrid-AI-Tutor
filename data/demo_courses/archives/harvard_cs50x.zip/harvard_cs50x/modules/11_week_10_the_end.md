# CS50x Week 10: The End

> Source: CS50x lecture notes, David J. Malan, Harvard University. https://cs50.harvard.edu/x/notes/10/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web page to Markdown; navigation, images and videos removed.

# The End

- Recap

- Final Project

- Looking Ahead

- Thank You!

- Summing Up

## Recap

- Over these past ten weeks, you have been drinking from the proverbial firehose.

- During this course, you learned to program in many different languages; indeed, our great hope is that you *learned how to program* in them all, regardless of the language.

- Consider the various topics we discussed over the last ten weeks: You have come so far and have gained so many skills.

- You should measure your success as the delta between your skill at the start of the course and your skill now, at the end of the course.

- Further, we hope that you *learned how to solve problems* above all else, how to take input, process it through an algorithm, and produce some output. To that point, we played a game where we drew a picture using verbal instructions.

- Notice how some verbal instructions were *higher level* and others were *lower level*, like the different programming languages utilized in this course.

- Notice how some instructions were more specific than others. Remember times when you had to refine your code to do exactly as you wanted.

- Also, notice how some instructions were abstracted away, like *draw arms*. This is similar to how we abstracted away code into functions.

- Looking at all the weeks of the course, you gathered tools and built skills. Above all, though, you learned how to teach yourself and leverage learning resources.

## Final Project

- Your final project is your opportunity to build a project, using these skills, that is of your specification and design. We hope you will join us for the CS50 Hackathon, an epic all-nighter wherein we work together on our final projects.

- Further, you should notice in the final project specification the opportunity to leverage AI-based tools outside the course’s own (not permitted in any other problem set).

- For those of you on campus, we hope that you will attend the CS50 Fair to showcase your final project.

## Looking Ahead

- As you journey from the work of this course to the world outside CS50, you may want to take a number of steps to prepare and adventure out.

- Journeying on, download and learn about VS Code. Cursor and Windsurf are other popular text editors.

- To be able to execute commands on the terminal, much like you did on CS50.dev, install command-line tools on your Mac or PC.

- Learn more about Git.

- Host a website using GitHub.

- If applicable, host a web app using AWS, Azure, Google Cloud, Cloudflare, Heroku, or Vercel.

- Ask questions in relevant online communities.

- Ask questions using AI-based tools like ChatGPT, Claude, Gemini, GitHub Copilot, Codex, or v0.

- Take any of our other CS50 courses.

- Join one of our many communities.

## Thank You!

- Thank you for engaging in this course!

- Many people made this course possible: Thank you for making this course possible and for supporting us so well!

## Summing Up

In this lesson, we reflected on your journey through this course. Specifically, we encourage you to…

- Take the programming skills you learned in this course to solve problems in the world.

- Take the new skills you acquired in this course and continue your learning!

- Finish strong and submit your final project.

- Quack!

This was CS50!
