# Harvard CS50x: CS50's Introduction to Computer Science (2026)

Open course material used as a demo and test course of the Hybrid AI Tutor (course type `ece`). See [../README.md](../README.md).

- **Source**: [https://cs50.harvard.edu/x/](https://cs50.harvard.edu/x/)
- **Author**: David J. Malan, Harvard University
- **License**: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Non-commercial use only; adaptations are shared under the same license.
- **Retrieved**: 2026-11-12
- **Changes**: files renamed and numbered as modules; web pages converted to Markdown with an attribution header. PDFs are unchanged.
- The authors and their institution do not endorse this project.

## Course-level documents

Uploaded to the course (not to a module): the syllabus and, where the course has them, the calendar, assignments and exams (questions only).

- `syllabus.md`
- `assignments/pset_0.md`
- `assignments/pset_1.md`
- `assignments/pset_2.md`
- `assignments/pset_3.md`
- `assignments/pset_4.md`
- `assignments/pset_5.md`
- `assignments/pset_6.md`
- `assignments/pset_7.md`
- `assignments/pset_8.md`
- `assignments/pset_9.md`
- `assignments/final_project.md`

## Instructor only

None.


## Modules

| Module | Title | File |
|---|---|---|
| 1 | Week 0: Scratch | `modules/01_week_0_scratch.md` |
| 2 | Week 1: C | `modules/02_week_1_c.md` |
| 3 | Week 2: Arrays | `modules/03_week_2_arrays.md` |
| 4 | Week 3: Algorithms | `modules/04_week_3_algorithms.md` |
| 5 | Week 4: Memory | `modules/05_week_4_memory.md` |
| 6 | Week 5: Data Structures | `modules/06_week_5_data_structures.md` |
| 7 | Week 6: Python | `modules/07_week_6_python.md` |
| 8 | Week 7: SQL | `modules/08_week_7_sql.md` |
| 9 | Week 8: HTML, CSS, JavaScript | `modules/09_week_8_html_css_javascript.md` |
| 10 | Week 9: Flask | `modules/10_week_9_flask.md` |
| 11 | Week 10: The End | `modules/11_week_10_the_end.md` |
