# CS50x pset 0

> Source: CS50x problem sets, David J. Malan, Harvard University. https://cs50.harvard.edu/x/psets/0/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web pages to Markdown; navigation, images and videos removed.

# Problem Set 0

Collaboration on problem sets is not permitted except to the extent that you may ask classmates and others for help so long as that help does not reduce to another doing your work for you, per the course’s policy on academic honesty.

The staff conducts random audits of submissions to CS50x. Students found to be in violation of this policy will be removed from the course. Students who have already completed CS50x, if found to be in violation, will have their CS50 Certificate permanently revoked.

## Preliminary Course Setup

- Visit this link, log in with your GitHub account (perhaps after signing up for one first), and click **Authorize cs50**.

- Check the box indicating that you’d like to grant course staff access to your submissions, and click **Join course**.

## What to Do

- Download and install the latest version of Chrome, if you don’t have it already.

- Submit Starting from Scratch.

## When to Do It

By 2027-06-30T23:59:00+00:00.

## Advice

Here are David’s examples from lecture if you’d like to review! To see the source code of each, click **See inside**.

## How to Get Help

- Ask for help in the course’s communities!


# Starting from Scratch

It’s time to choose your own adventure! Your assignment, quite simply, is to implement in Scratch, at scratch.mit.edu, any project of your choice, be it an interactive story, game, animation, or anything else, subject only to the following requirements:

- Your project must use at least two sprites, at least one of which must not be a cat.

- Your project must have at least three scripts total (i.e., not necessarily three per sprite).

- Your project must use at least one conditional, at least one loop, and at least one variable.

- Your project must use at least one custom block that you have made yourself (via **Make a Block**), which must take at least one input.

- Your project should be more complex than most of those demonstrated in lecture (many of which, though instructive, were quite short) but it can be less complex than Oscartime and Ivy’s Hardest Game.

To meet these requirements, your project should probably use a few dozen puzzle pieces overall. And your code should ideally be not only correct but also well-designed. If one of your scripts is getting a bit long, try to break it up into multiple scripts (each of which does something specific). And try to leverage “abstraction” where possible: if you can imagine giving a descriptive name to a sequence of blocks (e.g., **meow**), those could probably be moved to a custom block!

If you’d like some inspiration from past students, here are just a few:

It’s Raining Men, from lecture

Soccer, a game

Cookie Love Story, an animation

Gingerbread tales, an interactive story

Intersection, a game

Hogwarts, a game

You might find these tutorials or starter projects helpful. And you’re welcome to explore scratch.mit.edu for inspiration. But try to think of an idea on your own, and then set out to implement it. However, don’t try to implement the entirety of your project all at once: tackle one piece at a time, just as we did in lecture. In other words, take baby steps: write a bit of code (i.e., drag and drop a few puzzle pieces), test, write a bit more, test, and so forth. And select **File > Save now** every few minutes so that you don’t lose any work!

If, along the way, you find it too difficult to implement some feature, try not to fret; alter your design or work around the problem. If you set out to implement an idea that you find fun, odds are you won’t find it too hard to satisfy the above requirements.

If you decide to import any backdrops, costumes, or sounds into your project, do take care to cite their origin with a comment!

Alright, off you go. Make us proud!

For this problem, it is **reasonable** to submit a Scratch project that you have previously submitted to another CS50 course, so long as it meets the above requirements.

Once finished with your project, select **File > Save now** one last time. Then select **File > Save to your computer** and keep that file so that you can submit it. If prompted by your computer to **Open** or **Save** the file, be sure to **Save** it.

## How to Submit

Be sure to complete **the steps below, in exactly that order**!

- Make sure you’ve completed the Preliminary Course Setup instructions.

- Go to submit.cs50.io/upload/cs50/problems/2026/x/scratch.

- Click “Choose File” and choose your `.sb3` file. Click **Submit**.

If you encounter the error “No files in this directory are expected by cs50/problems/2026/x/scratch”, please make sure your scratch project file name indeed ends with `.sb3`!

That’s it! Once your submission uploads, you should be redirected to your submission page. Click the submission link and then the **check50** link to see which requirements your project met. You are welcome to resubmit as many times as you’d like (before the deadline)! Note that if you upload a file whose size is larger than 10MB (which is quite large for a Scratch project) `check50` may struggle to process it. Best to make sure your file is smaller than that limit.

To view your current progress in the course, visit the course gradebook at cs50.me/cs50x!
