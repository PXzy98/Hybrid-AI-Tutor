# CS50x pset 6

> Source: CS50x problem sets, David J. Malan, Harvard University. https://cs50.harvard.edu/x/psets/6/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web pages to Markdown; navigation, images and videos removed.

# Problem Set 6

Collaboration on problem sets is not permitted except to the extent that you may ask classmates and others for help so long as that help does not reduce to another doing your work for you, per the course’s policy on academic honesty.

The staff conducts random audits of submissions to CS50x. Students found to be in violation of this policy will be removed from the course. Students who have already completed CS50x, if found to be in violation, will have their CS50 Certificate permanently revoked.

## What to Do

- Log into cs50.dev using your GitHub account

- Run `update50` in your codespace’s terminal window to ensure your codespace is up-to-date.

- Submit Hello in Python

- Submit one of:

this version of Mario in Python, if feeling less comfortable

this version of Mario in Python, if feeling more comfortable

- Submit one of:

Cash in Python, if feeling less comfortable

Credit in Python, if feeling more comfortable

- Submit Readability in Python

- Submit DNA in Python

If you submit both versions of Mario, we’ll record the higher of your two scores. If you submit both Cash and Credit, we’ll record the higher of your two scores.

## When to Do It

By 2027-06-30T23:59:00+00:00.

## Advice

- Try out any of David’s programs from Week 6.

## How to Get Help

- Ask for help in the course’s communities!

## Academic Honesty

- For Hello, Mario, Cash, Credit, and Readability, it is **reasonable** to look at your own implementations thereof in C and others’ implementations thereof *in C*.

- It is **not reasonable** to look at others’ implementations of the same *in Python*.

- Insofar as a goal of these problems is to teach you how to teach yourself a new language, keep in mind that these acts are not only **reasonable**, per the syllabus, but encouraged toward that end:

- Incorporating a few lines of code that you find online or elsewhere into your own code, provided that those lines are not themselves solutions to assigned problems and that you cite the lines’ origins.

- Turning to the web or elsewhere for instruction beyond the course’s own, for references, and for solutions to technical difficulties, but not for outright solutions to problem set’s problems or your own final project.


# Cash

## Problem to Solve

In a file called `cash.py` in a folder called `sentimental-cash`, write a program that asks the user how much change is owed and then spits out the minimum number of coins with which said change can be made. You can do this exactly as you did in Problem Set 1, except that your program this time should be written in Python, and you should assume that the user will input their change in dollars (e.g., 0.50 dollars instead of 50 cents).

## Demo

## Specification

- Use `get_float` from the CS50 Library to get the user’s input and `print` to output your answer. Assume that the only coins available are quarters (25¢), dimes (10¢), nickels (5¢), and pennies (1¢).

- We ask that you use `get_float` so that you can handle dollars and cents, albeit sans dollar sign. In other words, if some customer is owed $9.75 (as in the case where a newspaper costs 25¢ but the customer pays with a $10 bill), assume that your program’s input will be `9.75` and not `$9.75` or `975`. However, if some customer is owed $9 exactly, assume that your program’s input will be `9.00` or just `9` but, again, not `$9` or `900`. Of course, by nature of floating-point values, your program will likely work with inputs like `9.0` and `9.000` as well; you need not worry about checking whether the user’s input is “formatted” like money should be.

- If the user fails to provide a non-negative value, your program should re-prompt the user for a valid amount again and again until the user complies.

- Incidentally, so that we can automate some tests of your code, we ask that your program’s last line of output be only the minimum number of coins possible: an integer followed by a newline.

## How to Test

While `check50` is available for this problem, you’re encouraged to first test your code on your own for each of the following.

- Run your program as `python cash.py`, and wait for a prompt for input. Type in `0.41` and press enter. Your program should output `4`.

- Run your program as `python cash.py`, and wait for a prompt for input. Type in `0.01` and press enter. Your program should output `1`.

- Run your program as `python cash.py`, and wait for a prompt for input. Type in `0.15` and press enter. Your program should output `2`.

- Run your program as `python cash.py`, and wait for a prompt for input. Type in `1.60` and press enter. Your program should output `7`.

- Run your program as `python cash.py`, and wait for a prompt for input. Type in `23` and press enter. Your program should output `92`.

- Run your program as `python cash.py`, and wait for a prompt for input. Type in `4.2` and press enter. Your program should output `18`.

- Run your program as `python cash.py`, and wait for a prompt for input. Type in `-1` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

- Run your program as `python cash.py`, and wait for a prompt for input. Type in `foo` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

- Run your program as `python cash.py`, and wait for a prompt for input. Do not type anything, and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

### Correctness


```
check50 cs50/problems/2026/x/sentimental/cash
```


### Style


```
style50 cash.py
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/sentimental/cash
```


# Credit

## Problem to Solve

In a filed called `credit.py` in a folder called `sentimental-credit`, write a program that prompts the user for a credit card number and then reports (via `print`) whether it is a valid American Express, MasterCard, or Visa card number, exactly as you did in Problem Set 1. Your program this time should be written in Python!

## Demo

## Specification

- So that we can automate some tests of your code, we ask that your program’s last line of output be `AMEX\n` or `MASTERCARD\n` or `VISA\n` or `INVALID\n`, nothing more, nothing less.

- For simplicity, you may assume that the user’s input will be entirely numeric (i.e., devoid of hyphens, as might be printed on an actual card).

- Best to use `get_int` or `get_string` from CS50’s library to get users’ input, depending on how you to decide to implement this one.

## Hints

- It’s possible to use regular expressions to validate user input. You might use Python’s `re` module, for example, to check whether the user’s input is indeed a sequence of digits of the correct length.

## How to Test

While `check50` is available for this problem, you’re encouraged to first test your code on your own for each of the following.

- Run your program as `python credit.py`, and wait for a prompt for input. Type in `378282246310005` and press enter. Your program should output `AMEX`.

- Run your program as `python credit.py`, and wait for a prompt for input. Type in `371449635398431` and press enter. Your program should output `AMEX`.

- Run your program as `python credit.py`, and wait for a prompt for input. Type in `5555555555554444` and press enter. Your program should output `MASTERCARD`.

- Run your program as `python credit.py`, and wait for a prompt for input. Type in `5105105105105100` and press enter. Your program should output `MASTERCARD`.

- Run your program as `python credit.py`, and wait for a prompt for input. Type in `4111111111111111` and press enter. Your program should output `VISA`.

- Run your program as `python credit.py`, and wait for a prompt for input. Type in `4012888888881881` and press enter. Your program should output `VISA`.

- Run your program as `python credit.py`, and wait for a prompt for input. Type in `1234567890` and press enter. Your program should output `INVALID`.

### Correctness


```
check50 cs50/problems/2026/x/sentimental/credit
```


### Style


```
style50 credit.py
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/sentimental/credit
```


# DNA

## Problem to Solve

DNA, the carrier of genetic information in living things, has been used in criminal justice for decades. But how, exactly, does DNA profiling work? Given a sequence of DNA, how can forensic investigators identify to whom it belongs?

In a file called `dna.py` in a folder called `dna`, implement a program that identifies to whom a sequence of DNA belongs.

## Demo

## Distribution Code

For this problem, you’ll extend the functionality of code provided to you by CS50’s staff.

Download the distribution codeLog into cs50.dev, click on your terminal window, and execute `cd` by itself. You should find that your terminal window’s prompt resembles the below:


```
$
```


Next execute


```
wget https://cdn.cs50.net/2026/x/psets/6/dna.zip
```


in order to download a ZIP called `dna.zip` into your codespace.

Then execute


```
unzip dna.zip
```


to create a folder called `dna`. You no longer need the ZIP file, so you can execute


```
rm dna.zip
```


and respond with “y” followed by Enter at the prompt to remove the ZIP file you downloaded.

Now type


```
cd dna
```


followed by Enter to move yourself into (i.e., open) that directory. Your prompt should now resemble the below.


```
dna/ $
```


Execute `ls` by itself, and you should see a few files and folders:


```
databases/ dna.py sequences/
```


If you run into any trouble, follow these same steps again and see if you can determine where you went wrong!

## Background

DNA is really just a sequence of molecules called nucleotides, arranged into a particular shape (a double helix). Every human cell has billions of nucleotides arranged in sequence. Each nucleotide of DNA contains one of four different bases: adenine (A), cytosine (C), guanine (G), or thymine (T). Some portions of this sequence (i.e., genome) are the same, or at least very similar, across almost all humans, but other portions of the sequence have a higher genetic diversity and thus vary more across the population.

One place where DNA tends to have high genetic diversity is in Short Tandem Repeats (STRs). An STR is a short sequence of DNA bases that tends to repeat consecutively numerous times at specific locations inside of a person’s DNA. The number of times any particular STR repeats varies a lot among individuals. In the DNA samples below, for example, Alice has the STR `AGAT` repeated four times in her DNA, while Bob has the same STR repeated five times.

Using multiple STRs, rather than just one, can improve the accuracy of DNA profiling. If the probability that two people have the same number of repeats for a single STR is 5%, and the analyst looks at 10 different STRs, then the probability that two DNA samples match purely by chance is about 1 in 1 quadrillion (assuming all STRs are independent of each other). So if two DNA samples match in the number of repeats for each of the STRs, the analyst can be pretty confident they came from the same person. CODIS, the FBI’s DNA database, uses 20 different STRs as part of its DNA profiling process.

What might such a DNA database look like? Well, in its simplest form, you could imagine formatting a DNA database as a CSV file, wherein each row corresponds to an individual, and each column corresponds to a particular STR.


```
name,AGAT,AATG,TATC
Alice,28,42,14
Bob,17,22,19
Charlie,36,18,25
```


The data in the above file would suggest that Alice has the sequence `AGAT` repeated 28 times consecutively somewhere in her DNA, the sequence `AATG` repeated 42 times, and `TATC` repeated 14 times. Bob, meanwhile, has those same three STRs repeated 17 times, 22 times, and 19 times, respectively. And Charlie has those same three STRs repeated 36, 18, and 25 times, respectively.

So given a sequence of DNA, how might you identify to whom it belongs? Well, imagine that you looked through the DNA sequence for the longest consecutive sequence of repeated `AGAT`s and found that the longest sequence was 17 repeats long. If you then found that the longest sequence of `AATG` is 22 repeats long, and the longest sequence of `TATC` is 19 repeats long, that would provide pretty good evidence that the DNA was Bob’s. Of course, it’s also possible that once you take the counts for each of the STRs, it doesn’t match anyone in your DNA database, in which case you have no match.

In practice, since analysts know on which chromosome and at which location in the DNA an STR will be found, they can localize their search to just a narrow section of DNA. But we’ll ignore that detail for this problem.

Your task is to write a program that will take a sequence of DNA and a CSV file containing STR counts for a list of individuals and then output to whom the DNA (most likely) belongs.

## Specification

- The program should require as its first command-line argument the name of a CSV file containing the STR counts for a list of individuals and should require as its second command-line argument the name of a text file containing the DNA sequence to identify.

- If your program is executed with the incorrect number of command-line arguments, your program should print an error message of your choice (with `print`). If the correct number of arguments are provided, you may assume that the first argument is indeed the filename of a valid CSV file and that the second argument is the filename of a valid text file.

- Your program should open the CSV file and read its contents into memory.

- You may assume that the first row of the CSV file will be the column names. The first column will be the word `name` and the remaining columns will be the STR sequences themselves.

- Your program should open the DNA sequence and read its contents into memory.

- For each of the STRs (from the first line of the CSV file), your program should compute the longest run of consecutive repeats of the STR in the DNA sequence to identify. Notice that we’ve defined a helper function for you, `longest_match`, which will do just that!

- If the STR counts match exactly with any of the individuals in the CSV file, your program should print out the name of the matching individual.

- You may assume that the STR counts will not match more than one individual.

- If the STR counts do not match exactly with any of the individuals in the CSV file, your program should print `No match`.

## Hints

- You may find Python’s `csv` module helpful for reading CSV files into memory. Of particular help might be `csv.DictReader`.

- For instance, if a file like `foo.csv` has a header row, wherein each string is the name of some field, here’s how you might print those `fieldnames` as a `list`:


```
import csv

with open("foo.csv") as file:
    reader = csv.DictReader(file)
    print(reader.fieldnames)
```


- And here’s how you read all of the (other) rows from a CSV into a `list`, wherein each element is a `dict` that represents that row:


```
import csv

rows = []
with open("foo.csv") as file:
    reader = csv.DictReader(file)
    for row in reader:
        rows.append(row)
```


- The `open` and `read` functions might also prove useful for reading text files into memory.

- Consider what data structures might be helpful for keeping track of information in your program. A `list` or a `dict` may prove useful.

- Remember we’ve defined a function (`longest_match`) that, given both a DNA sequence and an STR as inputs, returns the maximum number of times that the STR repeats. You can then use that function in other parts of your program!

## Walkthrough

## How to Test

While `check50` is available for this problem, you’re encouraged to first test your code on your own for each of the following.

- Run your program as `python dna.py databases/small.csv sequences/1.txt`. Your program should output `Bob`.

- Run your program as `python dna.py databases/small.csv sequences/2.txt`. Your program should output `No match`.

- Run your program as `python dna.py databases/small.csv sequences/3.txt`. Your program should output `No match`.

- Run your program as `python dna.py databases/small.csv sequences/4.txt`. Your program should output `Alice`.

- Run your program as `python dna.py databases/large.csv sequences/5.txt`. Your program should output `Lavender`.

- Run your program as `python dna.py databases/large.csv sequences/6.txt`. Your program should output `Luna`.

- Run your program as `python dna.py databases/large.csv sequences/7.txt`. Your program should output `Ron`.

- Run your program as `python dna.py databases/large.csv sequences/8.txt`. Your program should output `Ginny`.

- Run your program as `python dna.py databases/large.csv sequences/9.txt`. Your program should output `Draco`.

- Run your program as `python dna.py databases/large.csv sequences/10.txt`. Your program should output `Albus`.

- Run your program as `python dna.py databases/large.csv sequences/11.txt`. Your program should output `Hermione`.

- Run your program as `python dna.py databases/large.csv sequences/12.txt`. Your program should output `Lily`.

- Run your program as `python dna.py databases/large.csv sequences/13.txt`. Your program should output `No match`.

- Run your program as `python dna.py databases/large.csv sequences/14.txt`. Your program should output `Severus`.

- Run your program as `python dna.py databases/large.csv sequences/15.txt`. Your program should output `Sirius`.

- Run your program as `python dna.py databases/large.csv sequences/16.txt`. Your program should output `No match`.

- Run your program as `python dna.py databases/large.csv sequences/17.txt`. Your program should output `Harry`.

- Run your program as `python dna.py databases/large.csv sequences/18.txt`. Your program should output `No match`.

- Run your program as `python dna.py databases/large.csv sequences/19.txt`. Your program should output `Fred`.

- Run your program as `python dna.py databases/large.csv sequences/20.txt`. Your program should output `No match`.

### Correctness


```
check50 cs50/problems/2026/x/dna
```


### Style


```
style50 dna.py
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/dna
```


# Hello, Again

## Problem to Solve

In a file called `hello.py` in a folder called `sentimental-hello`, implement a program that prompts a user for their name, and then prints `hello, so-and-so`, where `so-and-so` is their provided name, exactly as you did in Problem Set 1. Except that your program this time should be written in Python!

Hints

- Recall that you can get a `str` from a user with `get_string`, which is declared in the `cs50` library.

- Recall that you can print a `str` with `print`.

- Recall that you can create formatted strings in Python by prepending `f` to a string itself. For example, `f"{name}"` will substitute (“interpolate”) the value of the variable `name` where you’ve written `{name}`.

## Demo

## How to Test

While `check50` is available for this problem, you’re encouraged to first test your code on your own for each of the following.

- Run your program as `python hello.py`, and wait for a prompt for input. Type in `David` and press enter. Your program should output `hello, David`.

- Run your program as `python hello.py`, and wait for a prompt for input. Type in `Inno` and press enter. Your program should output `hello, Inno`.

- Run your program as `python hello.py`, and wait for a prompt for input. Type in `Kamryn` and press enter. Your program should output `hello, Kamryn`.

### Correctness


```
check50 cs50/problems/2026/x/sentimental/hello
```


### Style


```
style50 hello.py
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/sentimental/hello
```


# Mario

## Problem to Solve

In a file called `mario.py` in a folder called `sentimental-mario-less`, write a program that recreates a half-pyramid using hashes (`#`) for blocks, exactly as you did in Problem Set 1. Your program this time should be written in Python!

## Demo

## Specification

- To make things more interesting, first prompt the user with `get_int` for the half-pyramid’s height, a positive integer between `1` and `8`, inclusive.

- If the user fails to provide a positive integer no greater than `8`, you should re-prompt for the same again.

- Then, generate (with the help of `print` and one or more loops) the desired half-pyramid.

- Take care to align the bottom-left corner of your half-pyramid with the left-hand edge of your terminal window.

## How to Test

While `check50` is available for this problem, you’re encouraged to first test your code on your own for each of the following.

- Run your program as `python mario.py` and wait for a prompt for input. Type in `-1` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

- Run your program as `python mario.py` and wait for a prompt for input. Type in `0` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

- Run your program as `python mario.py` and wait for a prompt for input. Type in `1` and press enter. Your program should generate the below output. Be sure that the pyramid is aligned to the bottom-left corner of your terminal, and that there are no extra spaces at the end of each line.


```
#
```


- Run your program as `python mario.py` and wait for a prompt for input. Type in `2` and press enter. Your program should generate the below output. Be sure that the pyramid is aligned to the bottom-left corner of your terminal, and that there are no extra spaces at the end of each line.


```
 #
##
```


- Run your program as `python mario.py` and wait for a prompt for input. Type in `8` and press enter. Your program should generate the below output. Be sure that the pyramid is aligned to the bottom-left corner of your terminal, and that there are no extra spaces at the end of each line.


```
       #
      ##
     ###
    ####
   #####
  ######
 #######
########
```


- Run your program as `python mario.py` and wait for a prompt for input. Type in `9` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number. Then, type in `2` and press enter. Your program should generate the below output. Be sure that the pyramid is aligned to the bottom-left corner of your terminal, and that there are no extra spaces at the end of each line.


```
 #
##
```


- Run your program as `python mario.py` and wait for a prompt for input. Type in `foo` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

- Run your program as `python mario.py` and wait for a prompt for input. Do not type anything, and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

### Correctness


```
check50 cs50/problems/2026/x/sentimental/mario/less
```


### Style


```
style50 mario.py
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/sentimental/mario/less
```


# Mario

## Problem to Solve

In a file called `mario.py` in a folder called `sentimental-mario-more`, write a program that recreates a half-pyramid using hashes (`#`) for blocks, exactly as you did in Problem Set 1. Your program this time should be written in Python!

## Demo

## Specification

- To make things more interesting, first prompt the user with `get_int` for the half-pyramid’s height, a positive integer between `1` and `8`, inclusive. (The height of the half-pyramids pictured above happens to be `4`, the width of each half-pyramid `4`, with a gap of size `2` separating them).

- If the user fails to provide a positive integer no greater than `8`, you should re-prompt for the same again.

- Then, generate (with the help of `print` and one or more loops) the desired half-pyramids.

- Take care to align the bottom-left corner of your pyramid with the left-hand edge of your terminal window, and ensure that there are two spaces between the two pyramids, and that there are no additional spaces after the last set of hashes on each row.

## How to Test

While `check50` is available for this problem, you’re encouraged to first test your code on your own for each of the following.

- Run your program as `python mario.py` and wait for a prompt for input. Type in `-1` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

- Run your program as `python mario.py` and wait for a prompt for input. Type in `0` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

- Run your program as `python mario.py` and wait for a prompt for input. Type in `1` and press enter. Your program should generate the below output. Be sure that the pyramid is aligned to the bottom-left corner of your terminal, and that there are no extra spaces at the end of each line.


```
#  #
```


- Run your program as `python mario.py` and wait for a prompt for input. Type in `2` and press enter. Your program should generate the below output. Be sure that the pyramid is aligned to the bottom-left corner of your terminal, and that there are no extra spaces at the end of each line.


```
 #  #
##  ##
```


- Run your program as `python mario.py` and wait for a prompt for input. Type in `8` and press enter. Your program should generate the below output. Be sure that the pyramid is aligned to the bottom-left corner of your terminal, and that there are no extra spaces at the end of each line.


```
       #  #
      ##  ##
     ###  ###
    ####  ####
   #####  #####
  ######  ######
 #######  #######
########  ########
```


- Run your program as `python mario.py` and wait for a prompt for input. Type in `9` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number. Then, type in `2` and press enter. Your program should generate the below output. Be sure that the pyramid is aligned to the bottom-left corner of your terminal, and that there are no extra spaces at the end of each line.


```
 #  #
##  ##
```


- Run your program as `python mario.py` and wait for a prompt for input. Type in `foo` and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

- Run your program as `python mario.py` and wait for a prompt for input. Do not type anything, and press enter. Your program should reject this input as invalid, as by re-prompting the user to type in another number.

### Correctness


```
check50 cs50/problems/2026/x/sentimental/mario/more
```


### Style


```
style50 mario.py
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/sentimental/mario/more
```


# Readability

## Problem to Solve

Write, in a file called `readability.py` in a folder called `sentimental-readability`, a program that first asks the user to type in some text, and then outputs the grade level for the text, according to the Coleman-Liau formula, exactly as you did in Problem Set 2, except that your program this time should be written in Python.

## Demo

## Specification

- Recall that the Coleman-Liau index is computed as `0.0588 * L - 0.296 * S - 15.8`, where `L` is the average number of letters per 100 words in the text, and `S` is the average number of sentences per 100 words in the text.

- Use `get_string` from the CS50 Library to get the user’s input, and `print` to output your answer.

- Your program should count the number of letters, words, and sentences in the text. You may assume that a letter is any lowercase character from `a` to `z` or any uppercase character from `A` to `Z`, any sequence of characters separated by spaces should count as a word, and that any occurrence of a period, exclamation point, or question mark indicates the end of a sentence.

- Your program should print as output `"Grade X"` where `X` is the grade level computed by the Coleman-Liau formula, rounded to the nearest integer.

- If the resulting index number is 16 or higher (equivalent to or greater than a senior undergraduate reading level), your program should output `"Grade 16+"` instead of giving the exact index number. If the index number is less than 1, your program should output `"Before Grade 1"`.

## How to Test

While `check50` is available for this problem, you’re encouraged to first test your code on your own for each of the following.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `One fish. Two fish. Red fish. Blue fish.` and press enter. Your program should output `Before Grade 1`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `Would you like them here or there? I would not like them here or there. I would not like them anywhere.` and press enter. Your program should output `Grade 2`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `Congratulations! Today is your day. You're off to Great Places! You're off and away!` and press enter. Your program should output `Grade 3`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `Harry Potter was a highly unusual boy in many ways. For one thing, he hated the summer holidays more than any other time of year. For another, he really wanted to do his homework, but was forced to do it in secret, in the dead of the night. And he also happened to be a wizard.` and press enter. Your program should output `Grade 5`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `In my younger and more vulnerable years my father gave me some advice that I've been turning over in my mind ever since.` and press enter. Your program should output `Grade 7`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, "and what is the use of a book," thought Alice "without pictures or conversation?"` and press enter. Your program should output `Grade 8`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `When he was nearly thirteen, my brother Jem got his arm badly broken at the elbow. When it healed, and Jem's fears of never being able to play football were assuaged, he was seldom self-conscious about his injury. His left arm was somewhat shorter than his right; when he stood or walked, the back of his hand was at right angles to his body, his thumb parallel to his thigh.` and press enter. Your program should output `Grade 8`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `There are more things in Heaven and Earth, Horatio, than are dreamt of in your philosophy.` and press enter. Your program should output `Grade 9`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `It was a bright cold day in April, and the clocks were striking thirteen. Winston Smith, his chin nuzzled into his breast in an effort to escape the vile wind, slipped quickly through the glass doors of Victory Mansions, though not quickly enough to prevent a swirl of gritty dust from entering along with him.` and press enter. Your program should output `Grade 10`.

- Run your program as `python readability.py`, and wait for a prompt for input. Type in `A large class of computational problems involve the determination of properties of graphs, digraphs, integers, arrays of integers, finite families of finite sets, boolean formulas and elements of other countable domains.` and press enter. Your program should output `Grade 16+`.

### Correctness


```
check50 cs50/problems/2026/x/sentimental/readability
```


### Style


```
style50 readability.py
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/sentimental/readability
```
