# CS50x pset 2

> Source: CS50x problem sets, David J. Malan, Harvard University. https://cs50.harvard.edu/x/psets/2/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web pages to Markdown; navigation, images and videos removed.

# Problem Set 2

Collaboration on problem sets is not permitted except to the extent that you may ask classmates and others for help so long as that help does not reduce to another doing your work for you, per the course’s policy on academic honesty.

The staff conducts random audits of submissions to CS50x. Students found to be in violation of this policy will be removed from the course. Students who have already completed CS50x, if found to be in violation, will have their CS50 Certificate permanently revoked.

## What to Do

- Log into cs50.dev using your GitHub account **using Chrome, Edge, or Safari**, not Firefox

- Run `update50` in your codespace’s terminal window to ensure your codespace is up-to-date and, when prompted, click **Rebuild now**

- Submit Scrabble

- Submit Readability

- Submit one of:

Caesar, if feeling less comfortable

Substitution, if feeling more comfortable

If you submit both Caesar and Substitution, we’ll record the higher of your two scores.

## When to Do It

By 2027-06-30T23:59:00+00:00.

## Advice

- Try out any of David’s programs from class via Week 2’s examples.

- To see the manual pages for C functions, visit manual.cs50.io.

- If you see any errors when compiling your code with `make`, focus first on fixing the very first error you see, scrolling up as needed.

## How to Get Help

- Ask for help in the course’s communities!


# Caesar

## Problem to Solve

Supposedly, Caesar (yes, that Caesar) used to “encrypt” (i.e., conceal in a reversible way) confidential messages by shifting each letter therein by some number of places. For instance, he might write A as B, B as C, C as D, …, and, wrapping around alphabetically, Z as A. And so, to say HELLO to someone, Caesar might write IFMMP instead. Upon receiving such messages from Caesar, recipients would have to “decrypt” them by shifting letters in the opposite direction by the same number of places.

The secrecy of this “cryptosystem” relied on only Caesar and the recipients knowing a secret, the number of places by which Caesar had shifted his letters (e.g., 1). Not particularly secure by modern standards, but, hey, if you’re perhaps the first in the world to do it, pretty secure!

Unencrypted text is generally called *plaintext*. Encrypted text is generally called *ciphertext*. And the secret used is called a *key*.

To be clear, then, here’s how encrypting `HELLO` with a key of \(1\) yields `IFMMP`:

| plaintext | H | E | L | L | O |

| + key | \(1\) | \(1\) | \(1\) | \(1\) | \(1\) |

| = ciphertext | I | F | M | M | P |

More formally, Caesar’s algorithm (i.e., cipher) encrypts messages by “rotating” each letter by \(k\) positions. More formally, if \(p\) is some plaintext (i.e., an unencrypted message), \(p_i\) is the \(i^{th}\) character in \(p\), and \(k\) is a secret key (i.e., a non-negative integer), then each letter, \(c_i\), in the ciphertext, \(c\), is computed as

\[c_i = (p_i + k)\space\%\space26\]

wherein \(\%\space26\) here means “remainder when dividing by 26.” This formula perhaps makes the cipher seem more complicated than it is, but it’s really just a concise way of expressing the algorithm precisely. Indeed, for the sake of discussion, think of A (or a) as \(0\), B (or b) as \(1\), …, H (or h) as \(7\), I (or i) as \(8\), …, and Z (or z) as \(25\). Suppose that Caesar just wants to say `Hi` to someone confidentially using, this time, a key, \(k\), of 3. And so his plaintext, \(p\), is `Hi`, in which case his plaintext’s first character, \(p_0\), is `H` (aka 7), and his plaintext’s second character, \(p_1\), is `i` (aka 8). His ciphertext’s first character, \(c_0\), is thus `K`, and his ciphertext’s second character, \(c_1\), is thus `L`. Make sense?

In a file called `caesar.c` in a folder called `caesar`, write a program that enables you to encrypt messages using Caesar’s cipher. At the time the user executes the program, they should decide, by providing a command-line argument, what the key should be in the secret message they’ll provide at runtime. We shouldn’t necessarily assume that the user’s key is going to be a number; though you may assume that, if it is a number, it will be a positive integer.

## Demo

## Specification

Design and implement a program, `caesar`, that encrypts messages using Caesar’s cipher.

- Implement your program in a file called `caesar.c` in a directory called `caesar`.

- Your program must accept a single command-line argument, a non-negative integer. Let’s call it \(k\) for the sake of discussion.

- If your program is executed without any command-line arguments or with more than one command-line argument, your program should print an error message of your choice (with `printf`) and return from `main` a value of `1` (which tends to signify an error) immediately.

- If any of the characters of the command-line argument is not a decimal digit, your program should print the message `Usage: ./caesar key` and return from `main` a value of `1`.

- Do not assume that \(k\) will be less than or equal to 26. Your program should work for all non-negative integral values of \(k\) less than \(2^{31} - 26\). In other words, you don’t need to worry if your program eventually breaks if the user chooses a value for \(k\) that’s too big or almost too big to fit in an `int`. (Recall that an `int` can overflow.) But, even if \(k\) is greater than \(26\), alphabetical characters in your program’s input should remain alphabetical characters in your program’s output. For instance, if \(k\) is \(27\), `A` should not become `\` even though `\` is \(27\) positions away from `A` in ASCII, per asciitable.com; `A` should become `B`, since `B` is \(27\) positions away from `A`, provided you wrap around from `Z` to `A`.

- Your program must output `plaintext: ` (with two spaces but without a newline) and then prompt the user for a `string` of plaintext (using `get_string`).

- Your program must output `ciphertext: ` (with one space but without a newline) followed by the plaintext’s corresponding ciphertext, with each alphabetical character in the plaintext “rotated” by *k* positions; non-alphabetical characters should be outputted unchanged.

- Your program must preserve case: capitalized letters, though rotated, must remain capitalized letters; lowercase letters, though rotated, must remain lowercase letters.

- After outputting ciphertext, you should print a newline. Your program should then exit by returning `0` from `main`.

## Advice

How to begin? Let’s approach this problem one step at a time.

### Pseudocode

First write, try to write a `main` function in `caesar.c` that implements the program using just pseudocode, even if not (yet!) sure how to write it in actual code.

HintThere’s more than one way to do this, so here’s just one!


```
int main(int argc, string argv[])
{
    // Make sure program was run with just one command-line argument

    // Make sure every character in argv[1] is a digit

    // Convert argv[1] from a `string` to an `int`

    // Prompt user for plaintext

    // For each character in the plaintext:

        // Rotate the character if it's a letter
}
```


It’s okay to edit your own pseudocode after seeing ours here, but don’t simply copy/paste ours into your own!

### Counting Command-Line Arguments

Whatever your pseudocode, let’s first write only the C code that checks whether the program was run with a single command-line argument before adding additional functionality.

Specifically, modify `main` in `caesar.c` in such a way that, if the user provides no command-line arguments, or two or more, the function prints `"Usage: ./caesar key\n"` and then returns `1`, effectively exiting the program. If the user provides exactly one command-line argument, the program should print nothing and simply return `0`. The program should thus behave per the below.


```
$ ./caesar
Usage: ./caesar key
```



```
$ ./caesar 1 2 3
Usage: ./caesar key
```



```
$ ./caesar 1
```


Hints

- Recall that you can print with `printf`.

- Recall that a function can return a value with `return`.

- Recall that `argc` contains the number of command-line arguments passed to a program, plus the program’s own name.

### Checking the Key

Now that your program is (hopefully!) accepting input as prescribed, it’s time for another step.

Add to `caesar.c`, below `main`, a function called, e.g., `only_digits` that takes a `string` as an argument and returns `true` if that `string` contains only digits, `0` through `9`, else it returns `false`. Be sure to add the function’s prototype above `main` as well.

Hints

- Odds are you’ll want a prototype like:


```
bool only_digits(string s);
```


And be sure to include `cs50.h` atop your file, so that the compiler recognizes `string` (and `bool`).

- Recall that a `string` is just an array of `char`s.

- Recall that `strlen`, declared in `string.h`, calculates the length of a `string`.

- You might find `isdigit`, declared in `ctype.h`, to be helpful, per manual.cs50.io. But note that it only checks one `char` at a time!

Then modify `main` in such a way that it calls `only_digits` on `argv[1]`. If that function returns `false`, then `main` should print `"Usage: ./caesar key\n"` and return `1`. Else `main` should simply return `0`. The program should thus behave per the below:


```
$ ./caesar 42
```



```
$ ./caesar banana
Usage: ./caesar key
```


### Using the Key

Now modify `main` in such a way that it converts `argv[1]` to an `int`. You might find `atoi`, declared in `stdlib.h`, to be helpful, per manual.cs50.io. And then use `get_string` to prompt the user for some plaintext with `"plaintext: "`.

Then, implement a function called, e.g., `rotate`, that takes a `char` as input and also an `int`, and rotates that `char` by that many positions if it’s a letter (i.e., alphabetical), wrapping around from `Z` to `A` (and from `z` to `a`) as needed. If the `char` is not a letter, the function should instead return the same `char` unchanged.

Hints

- Odds are you’ll want a prototype like:


```
char rotate(char c, int n);
```


A function call like


```
rotate('A', 1)
```


or even


```
rotate('A', 27)
```


should thus return `'B'`. And a function call like


```
rotate('!', 13)
```


should return `'!'`.

- Recall that you can explicitly “cast” a `char` to an `int` with `(int)`, and an `int` to a `char` with `(char)`. Or you can do so implicitly by simply treating one as the other.

- Odds are you’ll want to subtract the ASCII value of `'A'` from any uppercase letters, so as to treat `'A'` as `0`, `'B'` as `1`, and so forth, while performing arithmetic. And then add it back when done with the same.

- Odds are you’ll want to subtract the ASCII value of `'a'` from any lowercase letters, so as to treat `'a'` as `0`, `'b'` as `1`, and so forth, while performing arithmetic. And then add it back when done with the same.

- You might find some other functions declared in `ctype.h` to be helpful, per manual.cs50.io.

- Odds are you’ll find `%` helpful when “wrapping around” arithmetically from a value like `25` to `0`.

Then modify `main` in such a way that it prints `"ciphertext: "` and then iterates over every `char` in the user’s plaintext, calling `rotate` on each, and printing the return value thereof.

Hints

- Recall that `printf` can print a `char` using `%c`.

- If you’re not seeing any output at all when you call `printf`, odds are it’s because you’re printing characters outside of the valid ASCII range from 0 to 127. Try printing characters temporarily as numbers (using `%i` instead of `%c`) to see what values you’re printing!

## Walkthrough

## How to Test

### Correctness


```
check50 cs50/problems/2026/x/caesar
```


How to Use `debug50`Looking to run `debug50`? You can do so as follows, after compiling your code successfully with `make`,


```
debug50 ./caesar KEY
```


wherein `KEY` is the key you give as a command-line argument to your program. Note that running


```
debug50 ./caesar
```


will (ideally!) cause your program end by prompting the user for a key.

### Style


```
style50 caesar.c
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/caesar
```


# Readability

## Problem to Solve

According to Scholastic, E.B. White’s *Charlotte’s Web* is between a second- and fourth-grade reading level, and Lois Lowry’s *The Giver* is between an eighth- and twelfth-grade reading level. What does it mean, though, for a book to be at a particular reading level?

Well, in many cases, a human expert might read a book and make a decision on the grade (i.e., year in school) for which they think the book is most appropriate. But an algorithm could likely figure that out too!

In a file called `readability.c` in a folder called `readability`, you’ll implement a program that calculates the approximate grade level needed to comprehend some text. Your program should print as output “Grade X” where “X” is the grade level computed, rounded to the nearest integer. If the grade level is 16 or higher (equivalent to or greater than a senior undergraduate reading level), your program should output “Grade 16+” instead of giving the exact index number. If the grade level is less than 1, your program should output “Before Grade 1”.

## Demo

## Background

So what sorts of traits are characteristic of higher reading levels? Well, longer words probably correlate with higher reading levels. Likewise, longer sentences probably correlate with higher reading levels, too.

A number of “readability tests” have been developed over the years that define formulas for computing the reading level of a text. One such readability test is the *Coleman-Liau index*. The Coleman-Liau index of a text is designed to output that (U.S.) grade level that is needed to understand some text. The formula is


```
index = 0.0588 * L - 0.296 * S - 15.8
```


where `L` is the average number of letters per 100 words in the text, and `S` is the average number of sentences per 100 words in the text.

## Advice

Write some code that you know will compile
```
#include 
#include 
#include 
#include 
#include 

int main(void)
{

}
```


Notice that you’ve now included a few header files that will give you access to functions which might help you solve this problem.

Write some pseudocode before writing more codeIf unsure how to solve the problem itself, break it down into smaller problems that you can probably solve first. For instance, this problem is really only a handful of problems:

- Prompt the user for some text

- Count the number of letters, words, and sentences in the text

- Compute the Coleman-Liau index

- Print the grade level

Let’s write some pseudcode as comments to remind you to do just that:


```
#include 
#include 
#include 
#include 
#include 

int main(void)
{
    // Prompt the user for some text

    // Count the number of letters, words, and sentences in the text

    // Compute the Coleman-Liau index

    // Print the grade level
}
```


Convert the pseudocode to codeFirst, consider how you might prompt the user for some text. Recall that `get_string`, a function in the CS50 library, can prompt the user for a string.


```
#include 
#include 
#include 
#include 
#include 

int main(void)
{
    // Prompt the user for some text
    string text = get_string("Text: ");

    // Count the number of letters, words, and sentences in the text

    // Compute the Coleman-Liau index

    // Print the grade level
}
```


Now that you’ve collected input from the user, you can begin to analyze that input. First, try to count the number of letters in the text. Consider letters to be uppercase or lowercase alphabetical character, not punctuation, digits, or other symbols.

One way to approach this problem is to create a function called `count_letters` that takes a string, `text`, as input, and then returns the number of letters in that text as an `int`.


```
int count_letters(string text)
{
    // Return the number of letters in text
}
```


You’ll need to write your own code to count the number of letters in the text. But someone more experienced than you may have already written a function to determine if a character is alphabetical. This is a good opportunity to use the CS50 manual, a collection of explanations of common functions in the C Standard Library.

You can integrate `count_letters` into the code you’ve already written, as follows.


```
#include 
#include 
#include 
#include 
#include 

int count_letters(string text);

int main(void)
{
    // Prompt the user for some text
    string text = get_string("Text: ");

    // Count the number of letters, words, and sentences in the text
    int letters = count_letters(text);

    // Compute the Coleman-Liau index

    // Print the grade level
}

int count_letters(string text)
{
    // Return the number of letters in text
}
```


Next, write a function to count words.


```
int count_words(string text)
{
    // Return the number of words in text
}
```


For the purpose of this problem, we’ll consider any sequence of characters separated by a space to be a word (so a hyphenated word like “sister-in-law” should be considered one word, not three). You may assume that a sentence:

- will contain at least one word;

- will not start or end with a space; and

- will not have multiple spaces in a row.

Under those assumptions, you might be able to find a relationship between the number words and the number of spaces. You are, of course, welcome to attempt a solution that will tolerate multiple spaces between words or indeed, no words!

You can now integrate `count_words` into your program as follows:


```
#include 
#include 
#include 
#include 
#include 

int count_letters(string text);
int count_words(string text);

int main(void)
{
    // Prompt the user for some text
    string text = get_string("Text: ");

    // Count the number of letters, words, and sentences in the text
    int letters = count_letters(text);
    int words = count_words(text);

    // Compute the Coleman-Liau index

    // Print the grade level
}

int count_letters(string text)
{
    // Return the number of letters in text
}

int count_words(string text)
{
    // Return the number of words in text
}
```


Finally, write a function to count sentences. You can consider any sequence of characters that ends with a `.` or a `!` or a `?` to be a sentence.


```
int count_sentences(string text)
{
    // Return the number of sentences in text
}
```


You can integrate `count_sentences` into your program as follows:


```
#include 
#include 
#include 
#include 
#include 

int count_letters(string text);
int count_words(string text);
int count_sentences(string text);

int main(void)
{
    // Prompt the user for some text
    string text = get_string("Text: ");

    // Count the number of letters, words, and sentences in the text
    int letters = count_letters(text);
    int words = count_words(text);
    int sentences = count_sentences(text);

    // Compute the Coleman-Liau index

    // Print the grade level
}

int count_letters(string text)
{
    // Return the number of letters in text
}

int count_words(string text)
{
    // Return the number of words in text
}

int count_sentences(string text)
{
    // Return the number of sentences in text
}
```


Finally, compute the Coleman-Liau index and print the resulting grade level.

- Recall that the Coleman-Liau index is computed using `index = 0.0588 * L - 0.296 * S - 15.8`

`L` is the average number of letters per 100 words in the text: that is, the number of letters divided by the number of words, all multiplied by 100.

`S` is the average number of sentences per 100 words in the text: that is, the number of sentences divided by the number of words, all multiplied by 100.

- You’ll want to round the result to the nearest whole number, so recall that `round` is declared in `math.h`, per manual.cs50.io.

- Recall that, when dividing values of type `int` in C, the result will also be an `int`, with any remainder (i.e., digits after the decimal point) discarded. Put another way, the result will be “truncated.” You might want to cast your one or more values to `float` before performing division when calculating `L` and `S`!

If the resulting index number is 16 or higher (equivalent to or greater than a senior undergraduate reading level), your program should output “Grade 16+” instead of outputting an exact index number. If the index number is less than 1, your program should output “Before Grade 1”.

## Walkthrough

## How to Test

Try running your program on the following texts, to ensure you see the specified grade level. Be sure to copy only the text, no extra spaces.

`One fish. Two fish. Red fish. Blue fish.` (Before Grade 1)

`Would you like them here or there? I would not like them here or there. I would not like them anywhere.` (Grade 2)

`Congratulations! Today is your day. You're off to Great Places! You're off and away!` (Grade 3)

`Harry Potter was a highly unusual boy in many ways. For one thing, he hated the summer holidays more than any other time of year. For another, he really wanted to do his homework, but was forced to do it in secret, in the dead of the night. And he also happened to be a wizard.` (Grade 5)

`In my younger and more vulnerable years my father gave me some advice that I've been turning over in my mind ever since.` (Grade 7)

`Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, "and what is the use of a book," thought Alice "without pictures or conversation?"` (Grade 8)

`When he was nearly thirteen, my brother Jem got his arm badly broken at the elbow. When it healed, and Jem's fears of never being able to play football were assuaged, he was seldom self-conscious about his injury. His left arm was somewhat shorter than his right; when he stood or walked, the back of his hand was at right angles to his body, his thumb parallel to his thigh.` (Grade 8)

`There are more things in Heaven and Earth, Horatio, than are dreamt of in your philosophy.` (Grade 9)

`It was a bright cold day in April, and the clocks were striking thirteen. Winston Smith, his chin nuzzled into his breast in an effort to escape the vile wind, slipped quickly through the glass doors of Victory Mansions, though not quickly enough to prevent a swirl of gritty dust from entering along with him.` (Grade 10)

`A large class of computational problems involve the determination of properties of graphs, digraphs, integers, arrays of integers, finite families of finite sets, boolean formulas and elements of other countable domains.` (Grade 16+)

### Correctness


```
check50 cs50/problems/2026/x/readability
```


### Style


```
style50 readability.c
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/readability
```


# Scrabble

## Problem to Solve

In the game of Scrabble, players create words to score points, and the number of points is the sum of the point values of each letter in the word.

| A | B | C | D | E | F | G | H | I | J | K | L | M | N | O | P | Q | R | S | T | U | V | W | X | Y | Z |

| 1 | 3 | 3 | 2 | 1 | 4 | 2 | 4 | 1 | 8 | 5 | 1 | 3 | 1 | 1 | 3 | 10 | 1 | 1 | 1 | 1 | 4 | 4 | 8 | 4 | 10 |

For example, if we wanted to score the word “CODE”, we would note that the ‘C’ is worth 3 points, the ‘O’ is worth 1 point, the ‘D’ is worth 2 points, and the ‘E’ is worth 1 point. Summing these, we get that “CODE” is worth 7 points.

In a file called `scrabble.c` in a folder called `scrabble`, implement a program in C that determines the winner of a short Scrabble-like game. Your program should prompt for input twice: once for “Player 1” to input their word and once for “Player 2” to input their word. Then, depending on which player scores the most points, your program should either print “Player 1 wins!”, “Player 2 wins!”, or “Tie!” (in the event the two players score equal points).

## Demo

## Advice and Hints

Write some code that you know will compile
```
#include 
#include 
#include 
#include 

int main(void)
{

}
```


Notice that you’ve now included a few header files that will give you access to functions which might help you solve this problem.

Write some pseudocode before writing more codeIf unsure how to solve the problem itself, break it down into smaller problems that you can probably solve first. For instance, this problem is really only a handful of problems:

- Prompt for the user for two words

- Compute the score of each word

- Print the winner

Let’s write some pseudcode as comments to remind you to do just that:


```
#include 
#include 
#include 
#include 

int main(void)
{
    // Prompt the user for two words

    // Compute the score of each word

    // Print the winner
}
```


Some problems in problem sets, like this one, might contain spoilers (like the next one) that ultimately walk you through the entire solution. While you are permitted to use this code, we really do strongly encourage you to try things out yourself first! The other problems in the problem set won’t have this sort of walkthrough, and typically the problem that contains the “full spoiler” is a warm-up version of the bigger problem you’ll later need to tackle.

Convert the pseudocode to codeFirst, consider how you might prompt the user for two words. Recall that `get_string`, a function in the CS50 library, can prompt the user for a string.


```
#include 
#include 
#include 
#include 

int main(void)
{
    // Prompt the user for two words
    string word1 = get_string("Player 1: ");
    string word2 = get_string("Player 2: ");

    // Compute the score of each word

    // Print the winner
}
```


Next consider how to compute the score of each word. Since the same scoring algorithm applies to both words, you have a good opportunity for *abstraction*. Here we’ll define a function called `compute_score` that takes a string, called `word`, as input, and then returns `word`’s score as an `int`.


```
#include 
#include 
#include 
#include 

int compute_score(string word);

int main(void)
{
    // Prompt the user for two words
    string word1 = get_string("Player 1: ");
    string word2 = get_string("Player 2: ");

    // Compute the score of each word
    int score1 = compute_score(word1);
    int score2 = compute_score(word2);

    // Print the winner   
}

int compute_score(string word)
{
    // Compute and return score for word
}
```


Now turn to implementing `compute_score`. To compute the score of a word, you need to know the point value of each letter in the word. You can associate letters and their point values with an *array*. Imagine an array of 26 `int`s, called `POINTS`, in which the first number is the point value for ‘A’, the second number is the point value for ‘B’, and so on. By declaring and initializing such an array outside of any single function, you can ensure this array is accessible to any function, including `compute_score`.


```
#include 
#include 
#include 
#include 

// Points assigned to each letter of the alphabet
int POINTS[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

int compute_score(string word);

int main(void)
{
    // Prompt the user for two words
    string word1 = get_string("Player 1: ");
    string word2 = get_string("Player 2: ");

    // Compute the score of each word
    int score1 = compute_score(word1);
    int score2 = compute_score(word2);

    // Print the winner   
}

int compute_score(string word)
{
    // Compute and return score for word
}
```


To implement `compute_score`, first try to find the point value of a single letter in `word`.

- Recall that to find the character at the nth index of a string, `s`, you can write `s[n]`. So `word[0]`, for example, will give you the first character of `word`.

- Now, recall that computers represent characters using ASCII, a standard that represents each character as a number.

- Recall too that the 0th index of `POINTS`, `POINTS[0]`, gives you the point value of ‘A’. Think about how you could transform the numeric representation of ‘A’ into the index of its point value. Now, what about ‘a’? You’ll need to apply different transformations to upper- and lower-case letters, so you may find the functions `isupper` and `islower` to be helpful to you.

- Keep in mind that characters that are *not* letters should be given zero points. For example, `!` is worth 0 points.

If you can properly calculate the value of *one* character in `word`, odds are you can use a loop to sum the points for the rest of the characters. Once you’ve tried the above on your own, consider this (quite revealing!) hint below.


```
#include 
#include 
#include 
#include 

// Points assigned to each letter of the alphabet
int POINTS[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

int compute_score(string word);

int main(void)
{
    // Prompt the user for two words
    string word1 = get_string("Player 1: ");
    string word2 = get_string("Player 2: ");

    // Compute the score of each word
    int score1 = compute_score(word1);
    int score2 = compute_score(word2);

    // Print the winner   
}

int compute_score(string word)
{
    // Keep track of score
    int score = 0;

    // Compute score for each character
    for (int i = 0, len = strlen(word); i Finally, finish your pseudocode’s last step: printing the winner. Recall that an `if` statement can be used to check if a condition is true, and that the additional usage of `else if` or `else` can check for other (exclusive) conditions.




```
if (/* Player 1 wins */)
{
// ...
}
else if (/* Player 2 wins */)
{
// ...
}
else
{
// ...
}
```






And once you’ve tried the above, feel free to take a peek at the hint (or, rather, complete solution!) below.




```
#include
#include
#include
#include

// Points assigned to each letter of the alphabet
int POINTS[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};

int compute_score(string word);

int main(void)
{
// Prompt the user for two words
string word1 = get_string("Player 1: ");
string word2 = get_string("Player 2: ");

// Compute the score of each word
int score1 = compute_score(word1);
int score2 = compute_score(word2);

// Print the winner
if (score1 > score2)
{
printf("Player 1 wins!\n");
}
else if (score1

## How to Test

Your program should behave per the examples below.


```
$ ./scrabble
Player 1: Question?
Player 2: Question!
Tie!
```



```
$ ./scrabble
Player 1: red
Player 2: wheelbarrow
Player 2 wins!
```



```
$ ./scrabble
Player 1: COMPUTER
Player 2: science
Player 1 wins!
```



```
$ ./scrabble
Player 1: Scrabble
Player 2: wiNNeR
Player 1 wins!
```


### Correctness


```
check50 cs50/problems/2026/x/scrabble
```


### Style


```
style50 scrabble.c
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/scrabble
```


# Substitution

## Problem to Solve

In a substitution cipher, we “encrypt” (i.e., conceal in a reversible way) a message by replacing every letter with another letter. To do so, we use a *key*: in this case, a mapping of each of the letters of the alphabet to the letter it should correspond to when we encrypt it. To “decrypt” the message, the receiver of the message would need to know the key, so that they can reverse the process: translating the encrypt text (generally called *ciphertext*) back into the original message (generally called *plaintext*).

A key, for example, might be the string `NQXPOMAFTRHLZGECYJIUWSKDVB`. This 26-character key means that `A` (the first letter of the alphabet) should be converted into `N` (the first character of the key), `B` (the second letter of the alphabet) should be converted into `Q` (the second character of the key), and so forth.

A message like `HELLO`, then, would be encrypted as `FOLLE`, replacing each of the letters according to the mapping determined by the key.

In a file called `substitution.c` in a folder called `substitution`, create a program that enables you to encrypt messages using a substitution cipher. At the time the user executes the program, they should decide, by providing a command-line argument, on what the key should be in the secret message they’ll provide at runtime.

## Demo

## Specification

Design and implement a program, `substitution`, that encrypts messages using a substitution cipher.

- Implement your program in a file called `substitution.c` in a directory called `substitution`.

- Your program must accept a single command-line argument, the key to use for the substitution. The key itself should be case-insensitive, so whether any character in the key is uppercase or lowercase should not affect the behavior of your program.

- If your program is executed without any command-line arguments or with more than one command-line argument, your program should print an error message of your choice (with `printf`) and return from `main` a value of `1` (which tends to signify an error) immediately.

- If the key is invalid (as by not containing 26 characters, containing any character that is not an alphabetic character, or not containing each letter exactly once), your program should print an error message of your choice (with `printf`) and return from `main` a value of `1` immediately.

- Your program must output `plaintext:` (without a newline) and then prompt the user for a `string` of plaintext (using `get_string`).

- Your program must output `ciphertext:` (without a newline) followed by the plaintext’s corresponding ciphertext, with each alphabetical character in the plaintext substituted for the corresponding character in the ciphertext; non-alphabetical characters should be outputted unchanged.

- Your program must preserve case: capitalized letters must remain capitalized letters; lowercase letters must remain lowercase letters.

- After outputting ciphertext, you should print a newline. Your program should then exit by returning `0` from `main`.

You might find one or more functions declared in `ctype.h` to be helpful, per manual.cs50.io.

## Walkthrough

## How to Test

### Correctness


```
check50 cs50/problems/2026/x/substitution
```


How to Use `debug50`Looking to run `debug50`? You can do so as follows, after compiling your code successfully with `make`,


```
debug50 ./substitution KEY
```


wherein `KEY` is the key you give as a command-line argument to your program. Note that running


```
debug50 ./substitution
```


will (ideally!) cause your program end by prompting the user for a key.

### Style


```
style50 substitution.c
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/substitution
```
