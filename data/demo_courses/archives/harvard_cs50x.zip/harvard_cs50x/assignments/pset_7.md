# CS50x pset 7

> Source: CS50x problem sets, David J. Malan, Harvard University. https://cs50.harvard.edu/x/psets/7/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web pages to Markdown; navigation, images and videos removed.

# Problem Set 7

Collaboration on problem sets is not permitted except to the extent that you may ask classmates and others for help so long as that help does not reduce to another doing your work for you, per the course’s policy on academic honesty.

The staff conducts random audits of submissions to CS50x. Students found to be in violation of this policy will be removed from the course. Students who have already completed CS50x, if found to be in violation, will have their CS50 Certificate permanently revoked.

## What to Do

- Log into cs50.dev using your GitHub account

- Run `update50` in your codespace’s terminal window to ensure your codespace is up-to-date and, when prompted, click **Rebuild now**

- Submit Songs

- Submit Movies

- Submit Fiftyville

## When to Do It

By 2027-06-30T23:59:00+00:00.

## Advice

- Head to w3schools.com/sql for a handy reference!

## How to Get Help

- Ask for help in the course’s communities!


# Fiftyville

## Problem to Solve

The CS50 Duck has been stolen! The town of Fiftyville has called upon you to solve the mystery of the stolen duck. Authorities believe that the thief stole the duck and then, shortly afterwards, took a flight out of town with the help of an accomplice. Your goal is to identify:

- Who the thief is,

- What city the thief escaped to, and

- Who the thief’s accomplice is who helped them escape

All you know is that the theft **took place on July 28, 2025** and that it **took place on Humphrey Street**.

How will you go about solving this mystery? The Fiftyville authorities have taken some of the town’s records from around the time of the theft and prepared a SQLite database for you, `fiftyville.db`, which contains tables of data from around the town. You can query that table using SQL `SELECT` queries to access the data of interest to you. Using just the information in the database, your task is to solve the mystery.

## Demo

## Getting Started

For this problem, you’ll use a database provided to you by CS50’s staff.

Download the distribution codeLog into cs50.dev, click on your terminal window, and execute `cd` by itself. You should find that your terminal window’s prompt resembles the below:


```
$
```


Next execute


```
wget https://cdn.cs50.net/2026/x/psets/7/fiftyville.zip
```


in order to download a ZIP called `fiftyville.zip` into your codespace.

Then execute


```
unzip fiftyville.zip
```


to create a folder called `fiftyville`. You no longer need the ZIP file, so you can execute


```
rm fiftyville.zip
```


and respond with “y” followed by Enter at the prompt to remove the ZIP file you downloaded.

Now type


```
cd fiftyville
```


followed by Enter to move yourself into (i.e., open) that directory. Your prompt should now resemble the below.


```
fiftyville/ $
```


Execute `ls` by itself, and you should see a few files:


```
answers.txt  fiftyville.db  log.sql
```


If you run into any trouble, follow these same steps again and see if you can determine where you went wrong!

## Specification

For this problem, equally as important as solving the mystery itself is the process that you use to solve the mystery. In `log.sql`, keep a log of all SQL queries that you run on the database. Above each query, label each with a comment (in SQL, comments are any lines that begin with `--`) describing why you’re running the query and/or what information you’re hoping to get out of that particular query. You can use comments in the log file to add additional notes about your thought process as you solve the mystery: ultimately, this file should serve as evidence of the process you used to identify the thief!

As you write your queries, you may notice that some of them can become quite complex. To help keep your queries readable, see principles of good style at sqlstyle.guide. The indentation section may be particularly helpful!

Once you solve the mystery, complete each of the lines in `answers.txt` by filling in the name of the thief, the city that the thief escaped to, and the name of the thief’s accomplice who helped them escape town. (Be sure not to change any of the existing text in the file or to add any other lines to the file!)

Ultimately, you should submit both your `log.sql` and `answers.txt` files.

## Walkthrough

## Hints

- Execute `sqlite3 fiftyville.db` to begin running queries on the database.

- While running `sqlite3`, executing `.tables` will list all of the tables in the database.

- While running `sqlite3`, executing `.schema TABLE_NAME`, where `TABLE_NAME` is the name of a table in the database, will show you the `CREATE TABLE` command used to create the table. This can be helpful for knowing which columns to query!

- You may find it helpful to start with the `crime_scene_reports` table. Start by looking for a crime scene report that matches the date and the location of the crime.

- See this SQL keywords reference for some SQL syntax that may be helpful!

## How to Test

### Correctness


```
check50 cs50/problems/2026/x/fiftyville
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/fiftyville
```


# Movies

**Changes for 2026:** `5.sql` now requires matching movies that begin with “Harry Potter and the “ (not just “Harry Potter”). `9.sql` now requires outputting **two columns** (the ID and name of each person), not just names. If you started this problem prior to 2026, be sure to update your queries accordingly!

## Problem to Solve

Provided to you is a file called `movies.db`, a SQLite database that stores data from IMDb about movies, the people who directed and starred in them, and their ratings. Write SQL queries to answer questions about this database of movies.

## Demo

## Getting Started

For this problem, you’ll use a database provided to you by CS50’s staff.

Download the distribution codeLog into cs50.dev, click on your terminal window, and execute `cd` by itself. You should find that your terminal window’s prompt resembles the below:


```
$
```


Next execute


```
wget https://cdn.cs50.net/2026/x/psets/7/movies.zip
```


in order to download a ZIP called `movies.zip` into your codespace.

Then execute


```
unzip movies.zip
```


to create a folder called `movies`. You no longer need the ZIP file, so you can execute


```
rm movies.zip
```


and respond with “y” followed by Enter at the prompt to remove the ZIP file you downloaded.

Now type


```
cd movies
```


followed by Enter to move yourself into (i.e., open) that directory. Your prompt should now resemble the below.


```
movies/ $
```


Execute `ls` by itself, and you should see 13 .sql files, as well as `movies.db`.

If you run into any trouble, follow these same steps again and see if you can determine where you went wrong!

## Specification

For each of the following problems, you should write a single SQL query that outputs the results specified by each problem. Your response must take the form of a single SQL query, though you may nest other queries inside of your query. You **should not** assume anything about the `id`s of any particular movies or people: your queries should be accurate even if the `id` of any particular movie or person were different. Finally, each query should return only the data necessary to answer the question: if the problem only asks you to output the names of movies, for example, then your query should not also output each movie’s release year.

You’re welcome to check your queries’ results against IMDb itself, but realize that ratings on the website might differ from those in `movies.db`, as more votes might have been cast since we downloaded the data!

- In `1.sql`, write a SQL query to list the titles of all movies released in 2008.

- Your query should output a table with a single column for the title of each movie.

- In `2.sql`, write a SQL query to determine the birth year of Emma Stone.

- Your query should output a table with a single column and a single row (not counting the header) containing Emma Stone’s birth year.

- You may assume that there is only one person in the database with the name Emma Stone.

- In `3.sql`, write a SQL query to list the titles of all movies with a release date on or after 2018, in alphabetical order.

- Your query should output a table with a single column for the title of each movie.

- Movies released in 2018 should be included, as should movies with release dates in the future.

- In `4.sql`, write a SQL query to determine the number of movies with an IMDb rating of 10.0.

- Your query should output a table with a single column and a single row (not counting the header) containing the number of movies with a 10.0 rating.

- In `5.sql`, write a SQL query to list the titles and release years of all Harry Potter movies, in chronological order.

- Your query should output a table with two columns, one for the title of each movie and one for the release year of each movie.

- You may assume that the title of all Harry Potter movies will begin with the words “Harry Potter and the “, and that if a movie title begins with the words “Harry Potter and the “, it is a Harry Potter movie.

- In `6.sql`, write a SQL query to determine the average rating of all movies released in 2012.

- Your query should output a table with a single column and a single row (not counting the header) containing the average rating.

- In `7.sql`, write a SQL query to list all movies released in 2010 and their ratings, in descending order by rating. For movies with the same rating, order them alphabetically by title.

- Your query should output a table with two columns, one for the title of each movie and one for the rating of each movie.

- Movies that do not have ratings should not be included in the result.

- In `8.sql`, write a SQL query to list the names of all people who starred in Toy Story.

- Your query should output a table with a single column for the name of each person.

- You may assume that there is only one movie in the database with the title Toy Story.

- In `9.sql`, write a SQL query to list the ID and names of all people who starred in a movie released in 2004, ordered by birth year.

- Your query should output a table with two columns: one for the ID and one for the name of each person.

- People with the same birth year may be listed in any order.

- No need to worry about people who have no birth year listed, so long as those who do have a birth year are listed in order.

- If a person appeared in more than one movie in 2004, they should only appear in your results once.

- In `10.sql`, write a SQL query to list the names of all people who have directed a movie that received a rating of at least 9.0.

- Your query should output a table with a single column for the name of each person.

- If a person directed more than one movie that received a rating of at least 9.0, they should only appear in your results once.

- In `11.sql`, write a SQL query to list the titles of the five highest rated movies (in order) that Chadwick Boseman starred in, starting with the highest rated.

- Your query should output a table with a single column for the title of each movie.

- You may assume that there is only one person in the database with the name Chadwick Boseman.

- In `12.sql`, write a SQL query to list the titles of all movies in which both Bradley Cooper and Jennifer Lawrence starred.

- Your query should output a table with a single column for the title of each movie.

- You may assume that there is only one person in the database with the name Bradley Cooper.

- You may assume that there is only one person in the database with the name Jennifer Lawrence.

- In `13.sql`, write a SQL query to list the names of all people who starred in a movie in which Kevin Bacon also starred.

- Your query should output a table with a single column for the name of each person.

- There may be multiple people named Kevin Bacon in the database. Be sure to only select the Kevin Bacon born in 1958.

- Kevin Bacon himself should not be included in the resulting list.

## Hints

Understand the schema of `movies.db`Whenever you engage with a new database, it’s best to first understand its *schema*. In a terminal window, run `sqlite3 movies.db` so that you can begin executing queries on the database.

First, when `sqlite3` prompts you to provide a query, type `.schema` and press enter. This will output the `CREATE TABLE` statements that were used to generate each of the tables in the database. By examining those statements, you can identify the columns present in each table.

Notice that the `movies` table has an `id` column that uniquely identifies each movie, as well as columns for the `title` of a movie and the `year` in which the movie was released. The `people` table also has an `id` column, and also has columns for each person’s `name` and `birth` year.

Movie ratings, meanwhile, are stored in the `ratings` table. The first column in the table is `movie_id`: a foreign key that references the `id` of the `movies` table. The rest of the row contains data about the `rating` for each movie and the number of `votes` the movie has received on IMDb.

Finally, the `stars` and `directors` tables match people to the movies in which they acted or directed. (Only principal stars and directors are included.) Each table has just two columns: `movie_id` and `person_id`, which reference a specific movie and person, respectively.

The challenge ahead of you is to write SQL queries to answer a variety of different questions by selecting data from one or more of these tables.

Consistently style your queriesSee sqlstyle.guide for pointers on good style in SQL, especially as your queries get more complex!

List the titles of all movies released in 2008Recall that you can select one (or more) columns from a database using `SELECT`, per the example below,


```
SELECT column0, column1 FROM table;
```


where `column0` is the title of one column, and `column1` is the title of another.

And recall that you can filter the rows returned in a query with the `WHERE` keyword, followed by a condition. You can use `=`, `>`, `<`, and other operators too.


```
SELECT column FROM table
WHERE condition;
```


See this SQL keywords reference for some SQL syntax that may be helpful!

Determine the birth year of Emma StoneRecall that a `WHERE` clause can evaluate conditions not just with numbers, but with strings.

List the titles of all movies with a release date on or after 2018, in alphabetical orderTry breaking this query into two steps. First, find the movies with a release date on or after 2018. Then, put those movies’ titles in alphabetical order.

To find the movies with a release date on or after 2018, recall that a condition in SQL supports the use of many common comparison operators, including `>=` for “greater than or equal to.” Check to see if your query returns the correct number of movies, per How to Test.

Finally, sort the query’s results alphabetically by title. Recall that `ORDER BY` can sort data by a column in your results, per the example below.


```
...
ORDER BY column;
```


Determine the number of movies with an IMDb rating of 10.0Notice this question asks you not for *individual* movies with a rating of 10.0, but for the *number* of movies with such a rating. In other words, you should collect (“aggregate”) the results of your query into a single number (the number of rows). Recall that SQL supports an “aggregation function” called `COUNT`, which you can use on a column per the example below.


```
SELECT COUNT(column)
FROM table;
```


List the titles and release years of all Harry Potter movies, in chronological orderFor this query, you’ll likely want to make use of SQL’s `LIKE` keyword. Recall that `LIKE` can make use of so-called “wildcard characters”, such as `%`, that will match any character (or sequence thereof).


```
SELECT column0, column1
FROM table
WHERE column1 LIKE pattern;
```


Determine the average rating of all movies released in 2012Here’s another example of a query in which you’ll need to aggregate data. Consider SQL’s `AVG` aggregation function, to compute an average.

Consider, too, that this query makes use of data stored in two separate tables: `ratings` and `movies`. Recall that—so long as one table has a foreign key that matches a column in another table—you can combine two tables using SQL’s `JOIN` keyword. To use the `JOIN` keyword, you should specify the table you’d like to join and the column by which to do so.


```
SELECT column0
FROM table0
JOIN table1 ON table0.column1 = table1.column2
```


List all movies released in 2010 and their ratings, in descending order by ratingRecall that `ORDER BY` need not always sort in ascending order. You can specify that your results be sorted in *descending* order by appending `DESC`.


```
...
ORDER BY column DESC;
```


List the names of all people who starred in Toy StoryWhen you see a more complex query such as this one, it’s best to break it down into smaller pieces. Ultimately, your query should arrive at a list of names, per the below.


```
-- Select names
SELECT name
FROM people
WHERE ...
```


But how’s best to arrive at the names of those who starred in Toy Story? Consider that the `people` table alone doesn’t have this information (but the `stars` table might!). Indeed, the `stars` table combines two columns, `person_id` and `movie_id`: any person with a `person_id` that is associated with Toy Story’s `movie_id` starred in Toy Story.


```
-- Select names
SELECT name
FROM people
WHERE ...

-- Select person IDs
SELECT person_id
FROM stars
WHERE movie_id = ...
```


A natural next step, then, is to find Toy Story’s movie ID.


```
-- Select names
SELECT name
FROM people
WHERE ...

-- Select person IDs
SELECT person_id
FROM stars
WHERE movie_id = ...

-- Find Toy Story's ID
SELECT id
FROM movies
WHERE title = 'Toy Story';
```


Of course, you’ve presently written three *separate* queries. But notice that some queries (the first two) would be complete by including results of the query directly below them. The process of making a query that depends on the results of a “subquery” is called “nesting” queries. It’s quite the hint, but here’s one way to nest the above queries!


```
-- Select names
SELECT name
FROM people
WHERE id IN
(
    -- Select person IDs
    SELECT person_id
    FROM stars
    WHERE movie_id = (

        -- Select Toy Story's ID
        SELECT id
        FROM movies
        WHERE title = 'Toy Story'
    )
);
```


List the ID and names of all people who starred in a movie released in 2004, ordered by birth yearNotice that this query, like the previous, requires you to use data from multiple tables. Recall that you can “nest” queries in SQL, which allows you to break a larger query into smaller ones. Perhaps you could write queries to…

- Find the IDs of movies released in 2004

- Find the IDs of people who starred in those movies

- Find the IDs and names of people with those people IDs

Then, try nesting those queries to arrive at a single query that returns all the IDs and names of people who starred in a movie released in 2004. Consider how you might then order the results of your query.

As a closing note, keep in mind that multiple people can have the same name. Although each person should only appear in your results once, two stars having the same name does not necessarily mean they are the same person.

List the names of all people who have directed a movie that received a rating of at least 9.0Notice that this query, like the previous, requires you to use data from multiple tables. Recall that you can “nest” queries in SQL, which allows you to break a larger query into smaller ones. Perhaps you could write queries to…

- Find the IDs of movies with at least a 9.0 rating

- Find the IDs of people who directed those movies

- Find the names of people with those people IDs

Then, try nesting those queries to arrive at a single query that returns the names of all people who have directed a movie that received a rating of at least 9.0.

List the titles of the five highest rated movies (in order) that Chadwick Boseman starred in, starting with the highest ratedNotice that this query, like the previous, requires you to use data from multiple tables. Recall that you can “nest” queries in SQL, which allows you to break a larger query into smaller ones. Perhaps you could write queries to…

- Find the ID of Chadwick Boseman

- Find the IDs of movies associated with Chadwick Boseman’s ID

- Find the movie titles with those movie IDs

Then, try nesting those queries to arrive at a single query that returns the titles of Chadwick Boseman’s movies.

From there, you’ll need to determine the ratings of those titles and sort those titles by rating, in descending order. Consider how you could combine a relevant table (likely `ratings`!) and order the results by a relevant column.

Finally, read up on SQL’s `LIMIT` keyword, which will return the top \(n\) rows in a query.

List the titles of all movies in which both Bradley Cooper and Jennifer Lawrence starredNotice that this query, like the previous, requires you to use data from multiple tables. Recall that you can “nest” queries in SQL, which allows you to break a larger query into smaller ones. Perhaps you could write queries to…

- Find the ID of Bradley Cooper

- Find the ID of Jennifer Lawrence

- Find the IDs of movies associated with Bradley Cooper’s ID

- Find the IDs of movies associated with Jennifer Lawrence’s ID

- Find movie titles from the movie IDs associated with *both* Bradley Cooper and Jennifer Lawrence

Then, try nesting those queries to arrive at a single query that returns the movies in which both Bradley Cooper and Jennifer Lawrence starred.

Recall that you can build compound conditions in SQL using `AND` or `OR`.

List the names of all people who starred in a movie in which Kevin Bacon also starredNotice that this query, like the previous, requires you to use data from multiple tables. Recall that you can “nest” queries in SQL, which allows you to break a larger query into smaller ones. Perhaps you could write queries to…

- Find the ID of Kevin Bacon (the one born in 1958!)

- Find the IDs of movies associated with Kevin Bacon’s ID

- Find the IDs of people associated with those movie IDs

- Find the names of people with those people IDs

Then, try nesting those queries to arrive at a single query that returns the names of all people who starred in a movie in which Kevin Bacon also starred. **Keep in mind that you’ll want to exclude Kevin Bacon himself from the results!**

## Walkthrough

## Usage

To test your queries in VS Code, you can query the database by running


```
$ cat filename.sql | sqlite3 movies.db
```


where `filename.sql` is the file containing your SQL query.

You can also run


```
$ cat filename.sql | sqlite3 movies.db > output.txt
```


to redirect the output of the query to a text file called `output.txt`. (This can be useful for checking how many rows are returned by your query!)

## How to Test

While `check50` is available for this problem, you’re encouraged to instead test your code on your own for each of the following. You can run `sqlite3 movies.db` to run additional queries on the database to ensure that your result is correct.

If you’re using the `movies.db` database provided in this problem set’s distribution, you should find that

- Executing `1.sql` results in a table with 1 column and 10,647 rows.

- Executing `2.sql` results in a table with 1 column and 1 row.

- Executing `3.sql` results in a table with 1 column and 154,665 rows.

- Executing `4.sql` results in a table with 1 column and 1 row.

- Executing `5.sql` results in a table with 2 columns and 18 rows.

- Executing `6.sql` results in a table with 1 column and 1 row.

- Executing `7.sql` results in a table with 2 columns and 7,386 rows.

- Executing `8.sql` results in a table with 1 column and 10 rows.

- Executing `9.sql` results in a table with 2 columns and 36,219 rows.

- Executing `10.sql` results in a table with 1 column and 4,675 rows.

- Executing `11.sql` results in a table with 1 column and 5 rows.

- Executing `12.sql` results in a table with 1 column and 4 rows.

- Executing `13.sql` results in a table with 1 column and 550 rows.

Note that row counts do not include header rows that only show column names.

If your query returns a number of rows that is slightly different from the expected output, be sure that you’re properly handling duplicates! For queries that ask for a list of names, no one person should be listed twice, but two different people who have the same name should each be listed.

### Correctness


```
check50 cs50/problems/2026/x/movies
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/movies
```


## Acknowledgements

Information courtesy of
IMDb
(imdb.com).
Used with permission.


# Songs

## Problem to Solve

Write SQL queries to answer questions about a database of the 100 most-streamed songs on Spotify in 2018.

## Demo

## Getting Started

For this problem, you’ll use a database provided to you by CS50’s staff.

Download the distribution codeOpen VS Code.

Start by clicking inside your terminal window, then execute `cd` by itself. You should find that its “prompt” resembles the below.


```
$
```


Click inside of that terminal window and then execute


```
wget https://cdn.cs50.net/2026/x/psets/7/songs.zip
```


followed by Enter in order to download a ZIP called `songs.zip` in your codespace. Take care not to overlook the space between `wget` and the following URL, or any other character for that matter!

Now execute


```
unzip songs.zip
```


to create a folder called `songs`. You no longer need the ZIP file, so you can execute


```
rm songs.zip
```


and respond with “y” followed by Enter at the prompt to remove the ZIP file you downloaded.

Now type


```
cd songs
```


followed by Enter to move yourself into (i.e., open) that directory. Your prompt should now resemble the below.


```
songs/ $
```


If all was successful, you should execute


```
ls
```


and you should see 8 .sql files, `songs.db`, and `answers.txt`.

If you run into any trouble, follow these same steps again and see if you can determine where you went wrong!

## Understanding

Provided to you is a file called `songs.db`, a SQLite database that stores data from Spotify about songs and their artists. This dataset contains the top 100 streamed songs on Spotify in 2018. In a terminal window, run `sqlite3 songs.db` so that you can begin executing queries on the database.

First, when `sqlite3` prompts you to provide a query, type `.schema` and press enter. This will output the `CREATE TABLE` statements that were used to generate each of the tables in the database. By examining those statements, you can identify the columns present in each table.

Notice that every `artist` has an `id` and a `name`. Notice, too, that every song has a `name`, an `artist_id` (corresponding to the `id` of the artist of the song), as well as values for the danceability, energy, key, loudness, speechiness (presence of spoken words in a track), valence, tempo, and duration of the song (measured in milliseconds).

The challenge ahead of you is to write SQL queries to answer a variety of different questions by selecting data from one or more of these tables. After you do so, you’ll reflect on the ways Spotify might use this same data in their annual Spotify Wrapped campaign to characterize listeners’ habits.

## Implementation Details

For each of the following problems, you should write a single SQL query that outputs the results specified by each problem. Your response must take the form of a single SQL query, though you may nest other queries inside of your query. You **should not** assume anything about the `id`s of any particular songs or artists: your queries should be accurate even if the `id` of any particular song or person were different. Finally, each query should return only the data necessary to answer the question: if the problem only asks you to output the names of songs, for example, then your query should not also output each song’s tempo.

- In `1.sql`, write a SQL query to list the names of all songs in the database.

- Your query should output a table with a single column for the name of each song.

- In `2.sql`, write a SQL query to list the names of all songs in increasing order of tempo.

- Your query should output a table with a single column for the name of each song.

- In `3.sql`, write a SQL query to list the names of the top 5 longest songs, in descending order of length.

- Your query should output a table with a single column for the name of each song.

- In `4.sql`, write a SQL query that lists the names of any songs that have danceability, energy, and valence greater than 0.75.

- Your query should output a table with a single column for the name of each song.

- In `5.sql`, write a SQL query that returns the average energy of all the songs.

- Your query should output a table with a single column and a single row containing the average energy.

- In `6.sql`, write a SQL query that lists the names of songs that are by Post Malone.

- Your query should output a table with a single column for the name of each song.

- You should not make any assumptions about what Post Malone’s `artist_id` is.

- In `7.sql`, write a SQL query that returns the average energy of songs that are by Drake.

- Your query should output a table with a single column and a single row containing the average energy.

- You should not make any assumptions about what Drake’s `artist_id` is.

- In `8.sql`, write a SQL query that lists the names of the songs that feature other artists.

- Songs that feature other artists will include “feat.” in the name of the song.

- Your query should output a table with a single column for the name of each song.

## Hints

See this SQL keywords reference for some SQL syntax that may be helpful!

List the names of all songs in the databaseRecall that, to select all values in a table’s column, you can use SQL’s `SELECT` keyword. `SELECT` is followed by the column (or columns) you’d like to select, which is in turn followed by `FROM table` where `table` is the name of the table you’d like to select from.

In `1.sql`, then, try writing the following:


```
-- All songs in the database.
SELECT name
FROM songs;
```


List the names of all songs in increasing order of tempoRecall that SQL has an `ORDER BY` keyword, by which you can order the results of your query by the value in a certain column. For example, `ORDER BY tempo` will order results by the column `tempo`.

In `2.sql`, then, try writing the following:


```
-- All songs in increasing order of tempo.
SELECT name
FROM songs
ORDER BY tempo;
```


List the names of the top 5 longest songs, in descending order of lengthRecall that `ORDER BY` need not always sort in ascending order. You can specify that your results be sorted in *descending* order by appending `DESC`. For example, `ORDER BY duration_ms DESC` will list results in descending order, by duration.

And recall, too, that `LIMIT n` can specify that you only want the first \(n\) rows that match a specific query. For example, `LIMIT 5` will return only the first five results of the query.

In `3.sql`, then, try writing the following:


```
-- The names of the top 5 longest songs, in descending order of length.
SELECT name
FROM songs
ORDER BY duration_ms DESC
LIMIT 5;
```


List the names of any songs that have danceability, energy, and valence greater than 0.75Recall that you can filter results in SQL with `WHERE` clauses, which are followed by some condition which typically tests the values in a row’s columns.

Recall, too, that SQL’s operators function much the same way as C’s. For example, `>` evaluates to “true” when the value on the left is greater than the value on the right. You may chain these expressions together, using `AND` or `OR`, to form one larger condition.

In `4.sql`, then, try writing the following:


```
-- The names of any songs that have danceability, energy, and valence greater than 0.75.
SELECT name
FROM songs
WHERE danceability > 0.75 AND energy > 0.75 AND valence > 0.75;
```


Find average energy of all the songsRecall that SQL supports keywords not just to select particular rows, but also to *aggregate* the data in those rows. In particular, you might find the `AVG` keyword (to compute averages) useful. To aggregate the results of a column, just apply the aggregation function to that column. For example, `SELECT AVG(energy)` will find the average of the values in the energy column for the given query.

In `5.sql`, then, try writing the following:


```
-- The average energy of all the songs.
SELECT AVG(energy)
FROM songs;
```


List the names of songs that are by Post MaloneNotice that, if you execute `.schema songs` in your sqlite prompt, the `songs` table has song names but not artist names! Instead, `songs` has an `artist_id` column. To list the names of songs by Post Malone, then, you’ll first need to identify Post Malone’s artist id.


```
-- Identify Post Malone's artist id
SELECT id
FROM artists
WHERE name = 'Post Malone';
```


This query returns 54. Now, you could query the `songs` table for any song with Post Malone’s id.


```
SELECT name
FROM songs
WHERE artist_id = 54;
```


But, per the specification, you should be mindful not to assume knowledge of any ids. You could improve the design of this query by *nesting* your two queries.

In `6.sql`, then, try writing the following:


```
-- The names of songs that are by Post Malone.
SELECT name
FROM songs
WHERE artist_id =
(
    SELECT id
    FROM artists
    WHERE name = 'Post Malone'
);
```


Find the average energy of songs that are by DrakeNotice that, similar to the previous query, you’ll need to combine multiple tables to successfully run this query. You could again use nested subqueries, but consider another approach too!

Recall that you can use SQL’s `JOIN` keyword to combine multiple tables into one, so long as you specify which columns across those tables should ultimately match. For example, the following query joins the `songs` and `artists` tables, indicating that the `artist_id` column in the `songs` table and the `id` column in the `artists` table should match:


```
SELECT *
FROM songs
JOIN artists ON songs.artist_id = artists.id
```


With these two tables combined, it’s only a matter of filtering your selection to find the average energy of songs by Drake.

In `7.sql`, then, try writing the following:


```
-- The average energy of songs that are by Drake
SELECT AVG(energy)
FROM songs
JOIN artists ON songs.artist_id = artists.id
WHERE artists.name = 'Drake';
```


List the names of the songs that feature other artistsFor this query, note that songs which feature other artists typically have some mention of “feat.” in their title. Recall that SQL’s `LIKE` keyword can be used to match strings with certain phrases (like “feat.”!). To do so, you can use `%`: a wildcard character that matches any sequence of characters.

In `8.sql`, then, try writing the following:


```
-- The names of songs that feature other artists.
SELECT name
FROM songs
WHERE name LIKE '%feat.%';
```


## Walkthrough

Not sure how to solve?

## Spotify Wrapped

Spotify Wrapped is a feature presenting Spotify users’ 100 most played songs from the past year. In 2021, Spotify Wrapped calculated an “Audio Aura” for each user, a “reading of [their] two most prominent moods as dictated by [their] top songs and artists of the year.” Suppose Spotify determines an audio aura by looking at the average energy, valence, and danceability of a person’s top 100 songs from the past year. In `answers.txt`, reflect on the following questions:

- If `songs.db` contains the top 100 songs of one listener from 2018, how would you characterize their audio aura?

- Hypothesize about why the way you’ve calculated this aura might *not* be very representative of the listener. What better ways of calculating this aura would you propose?

Be sure to submit `answers.txt` along with each of your `.sql` files!

## How to Test

### Correctness


```
check50 cs50/problems/2026/x/songs
```


## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.


```
submit50 cs50/problems/2026/x/songs
```
