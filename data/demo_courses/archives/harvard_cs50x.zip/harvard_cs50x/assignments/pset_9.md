# CS50x pset 9

> Source: CS50x problem sets, David J. Malan, Harvard University. https://cs50.harvard.edu/x/psets/9/
> License: CC BY-NC-SA 4.0 (https://creativecommons.org/licenses/by-nc-sa/4.0/). Retrieved 2026-11-12.
> Changes: converted from the web pages to Markdown; navigation, images and videos removed.

# Problem Set 9

Collaboration on problem sets is not permitted except to the extent that you may ask classmates and others for help so long as that help does not reduce to another doing your work for you, per the course’s policy on academic honesty.

The staff conducts random audits of submissions to CS50x. Students found to be in violation of this policy will be removed from the course. Students who have already completed CS50x, if found to be in violation, will have their CS50 Certificate permanently revoked.

## What to Do

- Log into cs50.dev using your GitHub account

- Run `update50` in your codespace’s terminal window to ensure your codespace is up-to-date and, when prompted, click **Rebuild now**

- Submit Birthdays

- Submit Finance

## When to Do It

By 2027-06-30T23:59:00+00:00.

## How to Get Help

- Ask for help in the course’s communities!


# Birthdays

## Problem to Solve

Create a web application to keep track of friends’ birthdays.

## Getting Started

Download the distribution codeOpen cs50.dev.

Start by clicking inside your terminal window, then execute `cd` by itself. You should find that its “prompt” resembles the below.

```
$
```

Click inside of that terminal window and then execute

```
wget https://cdn.cs50.net/2026/x/psets/9/birthdays.zip
```

followed by Enter in order to download a ZIP called `birthdays.zip` in your codespace. Take care not to overlook the space between `wget` and the following URL, or any other character for that matter!

Now execute

```
unzip birthdays.zip
```

to create a folder called `birthdays`. You no longer need the ZIP file, so you can execute

```
rm birthdays.zip
```

and respond with “y” followed by Enter at the prompt to remove the ZIP file you downloaded.

Now type

```
cd birthdays
```

followed by Enter to move yourself into (i.e., open) that directory. Your prompt should now resemble the below.

```
birthdays/ $
```

If all was successful, you should execute

```
ls
```

and you should see the following files and folders:

```
app.py  birthdays.db  static/  templates/
```

If you run into any trouble, follow these same steps again and see if you can determine where you went wrong!

## Understanding

In `app.py`, you’ll find the start of a Flask web application. The application has one route (`/`) that accepts both `POST` requests (after the `if`) and `GET` requests (after the `else`). Currently, when the `/` route is requested via `GET`, the `index.html` template is rendered. When the `/` route is requested via `POST`, the user is redirected back to `/` via `GET`.

`birthdays.db` is a SQLite database with one table, `birthdays`, that has four columns: `id`, `name`, `month`, and `day`. There are a few rows already in this table, though ultimately your web application will support the ability to insert rows into this table!

In the `static` directory is a `styles.css` file containing the CSS code for this web application. No need to edit this file, though you’re welcome to if you’d like!

In the `templates` directory is an `index.html` file that will be rendered when the user views your web application.

## Implementation Details

Complete the implementation of a web application to let users store and keep track of birthdays.

- When the `/` route is requested via `GET`, your web application should display, in a table, all of the people in your database along with their birthdays.

- First, in `app.py`, add logic in your `GET` request handling to query the `birthdays.db` database for all birthdays. Pass all of that data to your `index.html` template.

- Then, in `index.html`, add logic to render each birthday as a row in the table. Each row should have two columns: one column for the person’s name and another column for the person’s birthday.

- When the `/` route is requested via `POST`, your web application should add a new birthday to your database and then re-render the index page.

- First, in `index.html`, add an HTML form. The form should let users type in a name, a birthday month, and a birthday day. Be sure the form submits to `/` (its “action”) with a method of `post`.

- Then, in `app.py`, add logic in your `POST` request handling to `INSERT` a new row into the `birthdays` table based on the data supplied by the user.

Optionally, you may also:

- Add the ability to delete and/or edit birthday entries.

- Add any additional features of your choosing!

## Hints

Create a form via which users can submit birthdaysIn `index.html`, notice the following TODO:

```
<!-- TODO: Create a form for users to submit a name, a month, and a day -->
```

Recall that, to create a form, you can use the `form` HTML element. You can create a `form` HTML element with the following opening and closing tags:

```
<form>
</form>
```

Of course, a form still needs input fields (and a button via which the user can submit the form!). Recall that HTML `input` elements create, among other things, input boxes within a form. You can specify their `type` attribute to allow them to accept `text` or `number`s. Also give the `input` elements a `name` attribute so you can differentiate them.

```
<form>
    <input name="name" type="text">
    <input name="month" type="number">
    <input name="day" type="number">
</form>
```

Your form might benefit from a button the user could click to submit their data. Add an `input` element of type `submit`, which will allow the user to do just that. If you’d like the button itself to have explanatory text, try setting the `value` attribute.

```
<form>
    <input name="name" type="text">
    <input name="month" type="number">
    <input name="day" type="number">
    <input type="submit" value="Add Birthday">
</form>
```

Where will the user’s data be submitted? Currently, nowhere! Recall that you can specify a form’s `action` attribute to dictate which route should be requested after the form is submitted. The form data will be submitted along with the resulting request. The `method` attribute specifies which HTTP request method to use when submitting the form.

```
<form action="/" method="post">
    <input name="name" type="text">
    <input name="month" type="number">
    <input name="day" type="number">
    <input type="submit" value="Add Birthday">
</form>
```

With that, your form should be perfectly functional, though it could still be improved! Consider adding `placeholder` values to spruce things up a bit:

```
<form action="/" method="post">
    <input name="name" placeholder="Name" type="text">
    <input name="month" placeholder="Month" type="number">
    <input name="day" placeholder="Day" type="number">
    <input type="submit" value="Add Birthday">
</form>
```

And consider adding some *client-side validation*, to ensure the user cooperates with the intent of your form. For example, an `input` field of type `number` can also have a `min` and `max` attribute specified, which determine the minimum and maximum value a user can enter.

```
<form action="/" method="post">
    <input name="name" placeholder="Name" type="text">
    <input name="month" placeholder="Month" type="number" min="1" max="12">
    <input name="day" placeholder="Day" type="number" min="1" max="31">
    <input type="submit" value="Add Birthday">
</form>
```

Add a user's form submission to the databaseIn `app.py`, notice the following TODO:

```
# TODO: Add the user's entry into the database
```

Recall that Flask has some handy methods to access form data submitted via `POST`! In particular:

```
# Access form data
request.form.get(NAME)
```

where `NAME` refers to the `name` attribute of the particular `input` element with submitted data. If your `input` elements were named `name`, `month`, and `day`, you could access (and store!) their values respectively with the following:

```
# Access form data
name = request.form.get("name")
month = request.form.get("month")
day = request.form.get("day")
```

Now the values submitted by the user in the `name`, `month`, and `day` input elements are available to you as Python variables.

The next step is to add these values to your database! Thanks to this particular line

```
db = SQL("sqlite:///birthdays.db")
```

`app.py` has already established a connection to `birthdays.db` under the name `db`. You can now execute SQL queries by calling `db.execute` with a valid SQL query. If you wanted to add Carter’s birthday on January 1st, you might run the following SQL statement:

```
INSERT INTO birthdays (name, month, day) VALUES('Carter', 1, 1);
```

Configure `app.py` to run that same query, but with placeholders for the values to insert, as follows:

```
# Access form data
name = request.form.get("name")
month = request.form.get("month")
day = request.form.get("day")

# Insert data into database
db.execute("INSERT INTO birthdays (name, month, day) VALUES(?, ?, ?)", name, month, day)
```

And that should do it! Try submitting the form, opening `birthdays.db`, and using a `SELECT` query to view the contents of the `birthdays` table. You should see the submitted form data available to you.

As you create more advanced applications, you’ll also want to add *server-side validation*: that is, a way to check whether the user’s data is valid *before* doing anything else! One of the first validations you might make is whether the user submitted any data at all! Should you try to retrieve form data with `request.form.get` where the user didn’t submit any, `request.form.get` will return an empty string. You can check for this value in Python as follows:

```
# Access form data
name = request.form.get("name")
if not name:
    return redirect("/")

month = request.form.get("month")
if not month:
    return redirect("/")

day = request.form.get("day")
if not day:
    return redirect("/")

# Insert data into database
db.execute("INSERT INTO birthdays (name, month, day) VALUES(?, ?, ?)", name, month, day)
```

Now, you won’t insert a row until you’re sure the user has provided all the data you need.

A few more things could still go wrong! What if the user doesn’t, in fact, provide a numeric value for `month` or `day`? One way to check is to `try` to convert the value to an integer with `int` and, if the conversion fails, to redirect the user back to the homepage.

```
# Access form data
name = request.form.get("name")
if not name:
    return redirect("/")

month = request.form.get("month")
if not month:
    return redirect("/")
try:
    month = int(month)
except ValueError:
    return redirect("/")

day = request.form.get("day")
if not day:
    return redirect("/")
try:
    day = int(day)
except ValueError:
    return redirect("/")

# Insert data into database
db.execute("INSERT INTO birthdays (name, month, day) VALUES(?, ?, ?)", name, month, day)
```

And even if the user has entered a number, best to check it’s in the right range!

```
# Access form data
name = request.form.get("name")
if not name:
    return redirect("/")

month = request.form.get("month")
if not month:
    return redirect("/")
try:
    month = int(month)
except ValueError:
    return redirect("/")
if month < 1 or month > 12:
    return redirect("/")

day = request.form.get("day")
if not day:
    return redirect("/")
try:
    day = int(day)
except ValueError:
    return redirect("/")
if day < 1 or day > 31:
    return redirect("/")

# Insert data into database
db.execute("INSERT INTO birthdays (name, month, day) VALUES(?, ?, ?)", name, month, day)
```

Render birthdays in `birthdays.db`Once a user can submit birthdays and store them in `birthdays.db`, your next task is to ensure those birthdays are rendered in `index.html`.

First, you’ll need to retrieve all birthdays from `birthdays.db`. You could so with the SQL query:

```
SELECT * FROM birthdays;
```

See the following TODO in `app.py`:

```
# TODO: Display the entries in the database on index.html
```

Consider configuring `app.py` to run this SQL query each time the page is loaded with a `GET` request:

```
# Query for all birthdays
birthdays = db.execute("SELECT * FROM birthdays")
```

Now, all birthdays in the `birthdays` table of `birthdays.db` are available to you in a Python variable named `birthdays`. In particular, the results of the SQL query are stored as a list of dictionaries. Each dictionary represents one row returned by the query, and each key in the dictionary corresponds to a column name of the `birthdays` table (i.e., “name”, “month”, and “day”).

To render these birthdays in `index.html`, you can rely on Flask’s `render_template` function. You can specify that `index.html` should be rendered with the `birthdays` variable by specifying a keyword argument, also called `birthdays`, and setting it equal to the `birthdays` variable you just recently created.

```
# Query for all birthdays
birthdays = db.execute("SELECT * FROM birthdays")

# Render birthdays page
return render_template("index.html", birthdays=birthdays)
```

To be clear, the name on the left-hand side of the `=`, `birthdays`, is the name under which you can access the birthdays data within `index.html` itself.

Now that `index.html` is being rendered with access to the birthdays data, you can use Jinja to render the data properly. Jinja, like Python, can loop through elements of a list. And Jinja, like Python, can access elements a dictionary by their keys. In this case, the Jinja syntax to do so is the name of the dictionary, followed by a `.`, then the name of the key to access.

```
{% for birthday in birthdays %}
    <tr>
        <td>{{ birthday.name }}</td>
        <td>{{ birthday.month }}/{{ birthday.day }}</td>
    </tr>
{% endfor %}
```

And that’s it! Try reloading the page to see the birthdays rendered.

### Walkthrough

This video was recorded when the course was still using CS50 IDE for writing code. Though the interface may look different from your codespace, the behavior of the two environments should be largely similar!

Not sure how to solve?

### Testing

No `check50` for this problem set! But be sure to test your web application by adding some birthdays and ensuring that the data appears in your table as expected.

Run `flask run` in your terminal while in your `birthdays` directory to start a web server that serves your Flask application.

## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.

```
submit50 cs50/problems/2026/x/birthdays
```


# C$50 Finance

Implement a website via which users can “buy” and “sell” stocks, à la the below.

## Background

If you’re not quite sure what it means to buy and sell stocks (i.e., shares of a company), head here for a tutorial.

You’re about to implement C$50 Finance, a web app via which you can manage portfolios of stocks. Not only will this tool allow you to check real stocks’ prices and portfolios’ values, it will also let you buy (okay, “buy”) and sell (okay, “sell”) stocks by querying for stocks’ prices.

Indeed, there are tools (one is known as IEX) that let you download stock quotes via their API (application programming interface) using URLs like `https://api.iex.cloud/v1/data/core/quote/nflx?token=API_KEY`. Notice how Netflix’s symbol (NFLX) is embedded in this URL; that’s how IEX knows whose data to return. That link won’t actually return any data because IEX requires you to use an API key, but if it did, you’d see a response in JSON (JavaScript Object Notation) format like this:

```
{
  "avgTotalVolume":6787785,
  "calculationPrice":"tops",
  "change":1.46,
  "changePercent":0.00336,
  "close":null,
  "closeSource":"official",
  "closeTime":null,
  "companyName":"Netflix Inc.",
  "currency":"USD",
  "delayedPrice":null,
  "delayedPriceTime":null,
  "extendedChange":null,
  "extendedChangePercent":null,
  "extendedPrice":null,
  "extendedPriceTime":null,
  "high":null,
  "highSource":"IEX real time price",
  "highTime":1699626600947,
  "iexAskPrice":460.87,
  "iexAskSize":123,
  "iexBidPrice":435,
  "iexBidSize":100,
  "iexClose":436.61,
  "iexCloseTime":1699626704609,
  "iexLastUpdated":1699626704609,
  "iexMarketPercent":0.00864679844447232,
  "iexOpen":437.37,
  "iexOpenTime":1699626600859,
  "iexRealtimePrice":436.61,
  "iexRealtimeSize":5,
  "iexVolume":965,
  "lastTradeTime":1699626704609,
  "latestPrice":436.61,
  "latestSource":"IEX real time price",
  "latestTime":"9:31:44 AM",
  "latestUpdate":1699626704609,
  "latestVolume":null,
  "low":null,
  "lowSource":"IEX real time price",
  "lowTime":1699626634509,
  "marketCap":192892118443,
  "oddLotDelayedPrice":null,
  "oddLotDelayedPriceTime":null,
  "open":null,
  "openTime":null,
  "openSource":"official",
  "peRatio":43.57,
  "previousClose":435.15,
  "previousVolume":2735507,
  "primaryExchange":"NASDAQ",
  "symbol":"NFLX",
  "volume":null,
  "week52High":485,
  "week52Low":271.56,
  "ytdChange":0.4790450244167119,
  "isUSMarketOpen":true
}
```

Notice how, between the curly braces, there’s a comma-separated list of key-value pairs, with a colon separating each key from its value. We’re going to be doing something very similar with our own stock database API.

Let’s turn our attention now to getting this problem’s distribution code!

## Getting Started

Log into cs50.dev, click on your terminal window, and execute `cd` by itself. You should find that your terminal window’s prompt resembles the below:

```
$
```

Next execute

```
wget https://cdn.cs50.net/2026/x/psets/9/finance.zip
```

in order to download a ZIP called `finance.zip` into your codespace.

Then execute

```
unzip finance.zip
```

to create a folder called `finance`. You no longer need the ZIP file, so you can execute

```
rm finance.zip
```

and respond with “y” followed by Enter at the prompt to remove the ZIP file you downloaded.

Now type

```
cd finance
```

followed by Enter to move yourself into (i.e., open) that directory. Your prompt should now resemble the below.

```
finance/ $
```

Execute `ls` by itself, and you should see a few files and folders:

```
app.py  finance.db  helpers.py  requirements.txt  static/  templates/
```

If you run into any trouble, follow these same steps again and see if you can determine where you went wrong!

### Running

Start Flask’s built-in web server (within `finance/`):

```
$ flask run
```

Visit the URL outputted by `flask` to see the distribution code in action. You won’t be able to log in or register, though, just yet!

Within `finance/`, run `sqlite3 finance.db` to open `finance.db` with `sqlite3`. If you run `.schema` in the SQLite prompt, notice how `finance.db` comes with a table called `users`. Take a look at its structure (i.e., schema). Notice how, by default, new users will receive $10,000 in cash. But if you run `SELECT * FROM users;`, there aren’t (yet!) any users (i.e., rows) therein to browse.

Another way to view `finance.db` is with a program called phpLiteAdmin. Click on `finance.db` in your codespace’s file browser, then click the link shown underneath the text “Please visit the following link to authorize GitHub Preview”. You should see information about the database itself, as well as a table, `users`, just like you saw in the `sqlite3` prompt with `.schema`.

### Understanding

#### `app.py`

Open up `app.py`. Atop the file are a bunch of imports, among them CS50’s SQL module and a few helper functions. More on those soon.

After configuring Flask, notice how this file disables caching of responses (provided you’re in debugging mode, which you are by default in your code50 codespace), lest you make a change to some file but your browser not notice. Notice next how it configures Jinja with a custom “filter,” `usd`, a function (defined in `helpers.py`) that will make it easier to format values as US dollars (USD). It then further configures Flask to store sessions on the local filesystem (i.e., disk) as opposed to storing them inside of (digitally signed) cookies, which is Flask’s default. The file then configures CS50’s SQL module to use `finance.db`.

Thereafter are a whole bunch of routes, only two of which are fully implemented: `login` and `logout`. Read through the implementation of `login` first. Notice how it uses `db.execute` (from CS50’s library) to query `finance.db`. And notice how it uses `check_password_hash` to compare hashes of users’ passwords. Also notice how `login` “remembers” that a user is logged in by storing his or her `user_id`, an INTEGER, in `session`. That way, any of this file’s routes can check which user, if any, is logged in. Finally, notice how once the user has successfully logged in, `login` will redirect to `"/"`, taking the user to their home page. Meanwhile, notice how `logout` simply clears `session`, effectively logging a user out.

Notice how most routes are “decorated” with `@login_required` (a function defined in `helpers.py` too). That decorator ensures that, if a user tries to visit any of those routes, he or she will first be redirected to `login` so as to log in.

Notice too how most routes support GET and POST. Even so, most of them (for now!) simply return an “apology,” since they’re not yet implemented.

#### `helpers.py`

Next take a look at `helpers.py`. Ah, there’s the implementation of `apology`. Notice how it ultimately renders a template, `apology.html`. It also happens to define within itself another function, `escape`, that it simply uses to replace special characters in apologies. By defining `escape` inside of `apology`, we’ve scoped the former to the latter alone; no other functions will be able (or need) to call it.

Next in the file is `login_required`. No worries if this one’s a bit cryptic, but if you’ve ever wondered how a function can return another function, here’s an example!

Thereafter is `lookup`, a function that, given a `symbol` (e.g., NFLX), returns a stock quote for a company in the form of a `dict` with three keys: `name`, whose value is a `str`; `price`, whose value is a `float`; and `symbol`, whose value is a `str`, a canonicalized (uppercase) version of a stock’s symbol, irrespective of how that symbol was capitalized when passed into `lookup`. Note that these are not “real-time” prices but do change over time, just like in the real world!

Last in the file is `usd`, a short function that simply formats a `float` as USD (e.g., `1234.56` is formatted as `$1,234.56`).

#### `requirements.txt`

Next take a quick look at `requirements.txt`. That file simply prescribes the packages on which this app will depend.

#### `static/`

Glance too at `static/`, inside of which is `styles.css`. That’s where some initial CSS lives. You’re welcome to alter it as you see fit.

#### `templates/`

Now look in `templates/`. In `login.html` is, essentially, just an HTML form, stylized with Bootstrap. In `apology.html`, meanwhile, is a template for an apology. Recall that `apology` in `helpers.py` took two arguments: `message`, which was passed to `render_template` as the value of `bottom`, and, optionally, `code`, which was passed to `render_template` as the value of `top`. Notice in `apology.html` how those values are ultimately used! And here’s why 0:-)

Last up is `layout.html`. It’s a bit bigger than usual, but that’s mostly because it comes with a fancy, mobile-friendly “navbar” (navigation bar), also based on Bootstrap. Notice how it defines a block, `main`, inside of which templates (including `apology.html` and `login.html`) shall go. It also includes support for Flask’s message flashing so that you can relay messages from one route to another for the user to see.

## Specification

### `register`

Complete the implementation of `register` in such a way that it allows a user to register for an account via a form.

- Require that a user input a username, implemented as a text field whose `name` is `username`. Render an apology if the user’s input is blank or the username already exists.

- Note that `cs50.SQL.execute` will raise a `ValueError` exception if you try to `INSERT` a duplicate username because we have created a `UNIQUE INDEX` on `users.username`. Be sure, then, to use `try` and `except` to determine if the username already exists.

- Require that a user input a password, implemented as a text field whose `name` is `password`, and then that same password again, implemented as a text field whose `name` is `confirmation`. Render an apology if either input is blank or the passwords do not match.

- Submit the user’s input via `POST` to `/register`.

`INSERT` the new user into `users`, storing a hash of the user’s password, not the password itself. Hash the user’s password with `generate_password_hash` Odds are you’ll want to create a new template (e.g., `register.html`) that’s quite similar to `login.html`.

Once you’ve implemented `register` correctly, you should be able to register for an account and log in (since `login` and `logout` already work)! And you should be able to see your rows via phpLiteAdmin or `sqlite3`.

### `quote`

Complete the implementation of `quote` in such a way that it allows a user to look up a stock’s current price.

- Require that a user input a stock’s symbol, implemented as a text field whose `name` is `symbol`.

- Submit the user’s input via `POST` to `/quote`.

- Odds are you’ll want to create two new templates (e.g., `quote.html` and `quoted.html`). When a user visits `/quote` via GET, render one of those templates, inside of which should be an HTML form that submits to `/quote` via POST. In response to a POST, `quote` can render that second template, embedding within it one or more values from `lookup`.

### `buy`

Complete the implementation of `buy` in such a way that it enables a user to buy stocks.

- Require that a user input a stock’s symbol, implemented as a text field whose `name` is `symbol`. Render an apology if the input is blank or the symbol does not exist (as per the return value of `lookup`).

- Require that a user input a number of shares, implemented as a text field whose `name` is `shares`. Render an apology if the input is not a positive integer.

- Submit the user’s input via `POST` to `/buy`.

- Upon completion, redirect the user to the home page.

- Odds are you’ll want to call `lookup` to look up a stock’s current price.

- Odds are you’ll want to `SELECT` how much cash the user currently has in `users`.

- Add one or more new tables to `finance.db` via which to keep track of the purchase. Store enough information so that you know who bought what at what price and when.

- Use appropriate SQLite types.

- Define `UNIQUE` indexes on any fields that should be unique.

- Define (non-`UNIQUE`) indexes on any fields via which you will search (as via `SELECT` with `WHERE`).

- Render an apology, without completing a purchase, if the user cannot afford the number of shares at the current price.

- You don’t need to worry about race conditions (or use transactions).

Once you’ve implemented `buy` correctly, you should be able to see users’ purchases in your new table(s) via phpLiteAdmin or `sqlite3`.

### `index`

Complete the implementation of `index` in such a way that it displays an HTML table summarizing, for the user currently logged in, which stocks the user owns, the numbers of shares owned, the current price of each stock, and the total value of each holding (i.e., shares times price). Also display the user’s current cash balance along with a grand total (i.e., stocks’ total value plus cash).

- Odds are you’ll want to execute multiple `SELECT`s. Depending on how you implement your table(s), you might find GROUP BY, HAVING, SUM, and/or WHERE of interest.

- Odds are you’ll want to call `lookup` for each stock.

### `sell`

Complete the implementation of `sell` in such a way that it enables a user to sell shares of a stock (that he or she owns).

- Require that a user input a stock’s symbol, implemented as a `select` menu whose `name` is `symbol`. Render an apology if the user fails to select a stock or if (somehow, once submitted) the user does not own any shares of that stock.

- Require that a user input a number of shares, implemented as a text field whose `name` is `shares`. Render an apology if the input is not a positive integer or if the user does not own that many shares of the stock.

- Submit the user’s input via `POST` to `/sell`.

- Upon completion, redirect the user to the home page.

- You don’t need to worry about race conditions (or use transactions).

### `history`

Complete the implementation of `history` in such a way that it displays an HTML table summarizing all of a user’s transactions ever, listing row by row each and every buy and every sell.

- For each row, make clear whether a stock was bought or sold and include the stock’s symbol, the (purchase or sale) price, the number of shares bought or sold, and the date and time at which the transaction occurred.

- You might need to alter the table you created for `buy` or supplement it with an additional table. Try to minimize redundancies.

### personal touch

Implement at least one personal touch of your choice:

- Allow users to change their passwords.

- Allow users to add additional cash to their account.

- Allow users to buy more shares or sell shares of stocks they already own via `index` itself, without having to type stocks’ symbols manually.

- Implement some other feature of comparable scope.

## Walkthrough

## Testing

Be sure to test your web app manually, as by

- registering a new user and verifying that their portfolio page loads with the correct information,

- requesting a quote using a valid stock symbol,

- purchasing one stock multiple times, verifying that the portfolio displays correct totals,

- selling all or some of a stock, again verifying the portfolio, and

- verifying that your history page shows all transactions for your logged in user.

Also test some unexpected usage, as by

- inputting alphabetical strings into forms when only numbers are expected,

- inputting zero or negative numbers into forms when only positive numbers are expected,

- inputting floating-point values into forms when only integers are expected,

- trying to spend more cash than a user has,

- trying to sell more shares than a user has,

- inputting an invalid stock symbol, and

- including potentially dangerous characters like `'` and `;` in SQL queries.

You can also check the validity of your HTML by clicking the **I ♥ VALIDATOR** button in the footer of each of your pages, which will POST your HTML to validator.w3.org.

Once satisfied, to test your code with `check50`, execute the below.

```
check50 cs50/problems/2026/x/finance
```

Be aware that `check50` will test your entire program as a whole. If you run it **before** completing all required functions, it may report errors on functions that are actually correct but depend on other functions.

## Style

```
style50 app.py
```

## Staff’s Solution

You’re welcome to stylize your own app differently, but here’s what the staff’s solution looks like!

https://finance.cs50.net/

Feel free to register for an account and play around. Do **not** use a password that you use on other sites.

It is **reasonable** to look at the staff’s HTML and CSS.

## Hints

- To format a value as a US dollar value (with cents listed to two decimal places), you can use the `usd` filter in your Jinja templates (printing values as `{{ value | usd }}` instead of `{{ value }}`.

Within `cs50.SQL` is an `execute` method whose first argument should be a `str` of SQL. If that `str` contains question mark parameters to which values should be bound, those values can be provided as additional named parameters to `execute`. See the implementation of `login` for one such example. The return value of `execute` is as follows:

- If `str` is a `SELECT`, then `execute` returns a `list` of zero or more `dict` objects, inside of which are keys and values representing a table’s fields and cells, respectively.

- If `str` is an `INSERT`, and the table into which data was inserted contains an autoincrementing `PRIMARY KEY`, then `execute` returns the value of the newly inserted row’s primary key.

- If `str` is a `DELETE` or an `UPDATE`, then `execute` returns the number of rows deleted or updated by `str`.

- Recall that `cs50.SQL` will log to your terminal window any queries that you execute via `execute` (so that you can confirm whether they’re as intended).

- Be sure to use question mark-bound parameters (i.e., a paramstyle of `named`) when calling CS50’s `execute` method, à la `WHERE ?`. Do **not** use f-strings, `format` or `+` (i.e., concatenation), lest you risk a SQL injection attack.

- If (and only if) already comfortable with SQL, you’re welcome to use SQLAlchemy Core or Flask-SQLAlchemy (i.e., SQLAlchemy ORM) instead of `cs50.SQL`.

- Recall that while you can validate values entered in an HTML form, savvy users may bypass those. Be sure that you are validating values server-side as well. In that same vein, if you’ve chosen to use Javascript in your solution, be sure that your application still works if your user has disabled Javascript.

- You’re welcome to add additional static files to `static/`.

- If adding extra functions in `helpers.py`, be sure to not open a new database connection. If a helper function requires use of the database, pass it in as a parameter instead of reinstantiating the connection.

- Odds are you’ll want to consult Jinja’s documentation when implementing your templates.

- It is **reasonable** to ask others to try out (and try to trigger errors in) your site.

- You’re welcome to alter the aesthetics of the sites, as via

bootswatch.com,

getbootstrap.com/docs/5.1/content,

getbootstrap.com/docs/5.1/components, and/or

memegen.link.

- You may find Flask’s documentation and Jinja’s documentation helpful!

## FAQs

### ImportError: No module named ‘application’

By default, `flask` looks for a file called `app.py` in your current working directory (because we’ve configured the value of `FLASK_APP`, an environment variable, to be `app.py`). If seeing this error, odds are you’ve run `flask` in the wrong directory!

### OSError: [Errno 98] Address already in use

If, upon running `flask`, you see this error, odds are you (still) have `flask` running in another tab. Be sure to kill that other process, as with ctrl-c, before starting `flask` again. If you haven’t any such other tab, execute `fuser -k 8080/tcp` to kill any processes that are (still) listening on TCP port 8080.

## How to Submit

In your terminal, execute the below to submit your work, answering the prompts that come up as well.

```
submit50 cs50/problems/2026/x/finance
```

### Why does my submission pass check50, but shows “No results” in my Gradebook after running submit50?

In some cases, `submit50` may not grade the assignment due to (1) inconsistent formatting in your `app.py` file, and/or (2) additional, unneeded files being submitted with the problem set. To fix these issues, run `style50 app.py` in the `finance` folder. Address any issues that are revealed. Next, examine the contents of your `finance` folder. Delete extraneous files, such as flask sessions or other files that are not part of your implementation of the problem set. Further, run `check50` again to ensure your submission still functions. Finally, run the `submit50` command above again. Your result will appear in your Gradebook within a few minutes.

Please note that if there is a numerical score next to your finance submission in the `submissions` area of your Gradebook, the procedure discussed above does not apply to you. Likely, you have not fully addressed the requirements of the problem set and should rely upon `check50` for clues as to what work remains.
